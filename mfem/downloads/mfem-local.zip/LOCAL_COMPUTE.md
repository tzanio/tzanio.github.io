# Local compute

Use the same Files, Editor, Terminal and GLVis interface with a separate process
running on your laptop. Files, Make, the compiler and MFEM solvers run natively.
The browser renders the interface and GLVis. This removes the emulated Linux
filesystem and CPU from the build path.

## Download and launch from the website

1. Click **Local compute** in the website header (inside **⋯** on phones), then
   **Download local companion**.
2. Unzip the download. Open your computer's terminal and change into the
   extracted directory containing `companion/` and `site/`.
3. Run the launch command below with your native MFEM checkout's absolute path.
4. Open the localhost link printed by the companion. Use that page's existing
   **Terminal** pane for subsequent builds and runs.

The browser terminal is connected to the native shell already. No separate
`xterm`, X11 server or `DISPLAY` setting is needed; GLVis renders in the browser.
The website cannot start the companion automatically. Keep its process running
while you work.

## Start with an existing checkout

Requirements: Python 3.12 or newer, Bash, Make, a C++17 compiler, and a **serial or
MPI** MFEM 4.10 checkout configured and built with Make. The visualization helpers
require its static `libmfem.a`. An MPI checkout also needs its normal MPI launcher
and configured libraries such as Hypre and METIS; the companion does not install
or reconfigure them.
Run from the unpacked workbench distribution:

```sh
python3.12 companion/serve.py --workspace /absolute/path/to/mfem --doctor
python3.12 companion/serve.py --workspace /absolute/path/to/mfem
```

The first start builds small native visualization helpers using that
checkout's configuration and library. It leaves the checkout's configuration
alone. Open the printed one-use pairing link; the command normally opens it for
you. The link expires after ten minutes. Pairing is retained in an HttpOnly cookie
for the browser session. Reload the resulting localhost page to reconnect.

The default interface port is 8765; use `--port 0` for an automatically chosen
port or `--port NUMBER` to select another. `--no-browser` only prints the link.
`--state-dir PATH` changes where helpers and shell history are stored. The default
is a checkout-specific directory under `~/.mfem-web/`.

In the browser terminal:

```sh
make ex1
./ex1
```

The editor and terminal use the actual selected checkout. Logical editor paths
such as `/root/mfem/examples/ex1.cpp` refer to that checkout; the native terminal's
`pwd` shows its real host path. After changing library implementation files,
rebuild the library as you normally would:

```sh
make -C .. -j4
make ex1
./ex1
```

Use your normal native compiler cache, debugger and installed command-line tools.
The browser-specific `mfem-browser-build` compiler and emulated `mfem-build`
wrapper are not needed in local mode. Build timings depend on your native MFEM
configuration, compiler and hardware; compare them with the same commands in a
regular terminal.

## Start with MFEM 4.10

To create a fresh serial checkout, run these commands in a parent directory of
your choosing:

```sh
git clone --branch v4.10 --depth 1 https://github.com/mfem/mfem.git mfem-local
cd mfem-local
make config MFEM_USE_MPI=NO MFEM_USE_METIS=NO
make -j4
```

Then run the companion from the unpacked distribution with the absolute path to
`mfem-local`. This initial library build is separate from subsequent example
builds. Existing configured Make checkouts are supported; arbitrary CMake
build-directory discovery is not implemented.

## Parallel examples

With an existing configured and built MPI checkout, launch the companion with
the same command. Use its browser terminal to run:

```sh
make ex1p
mpirun -np 2 ./ex1p
```

The native relay combines parallel rank streams before sending them to browser
GLVis. Parallel mesh/solution visualization supports **1–64 ranks**. Run only
**one visualizing MPI job at a time**: the standard GLVis stream has no job ID
with which to separate simultaneous jobs. Serial examples also work with an MPI
checkout. Other compatible MPI launcher commands can be used normally.

Two-rank `ex1p` and time-dependent `ex9p`, single-rank MPI visualization and native
mesh inspection have been tested on macOS. Parallel complex and quadrature
formats have not received the same end-to-end validation. Browser-only compute
continues to use the shipped serial MFEM configuration.

## Persistence and switching modes

Saved files persist on the host immediately. Unsaved editor drafts are saved in
this browser's IndexedDB, separately for each native checkout. Browser-only named
VM checkpoints are not used in local mode. Export remains the portable backup
for source and session state.

To move work between modes, choose **Export → Save & export changes**, then
**Import** on the destination page. This saves editor files and creates a small
source/data patch relative to the bundled MFEM 4.10 commit, including binary
changes, additions, deletions, permissions and links. It omits ignored build
outputs, Git history and browser session state. Import preserves unrelated
destination edits; each affected file must still match the base, and a new file
must not collide with an existing one. Any conflict rejects the whole patch
without writing files. Rebuild the affected targets after import.

Choose **Full workspace** instead to also carry saved tabs, layout, unsaved editor
drafts, terminal output and displayed GLVis data. Full archives include portable
Git content as described below.

Local archive compression and validation run in the companion. Transfers stream
through the browser without expanding the archive into a large JavaScript buffer.
The expanded archive limit is 512 MiB; omit unneeded generated results or use a
shallow Git checkout if the full history exceeds it.

Closing or hiding the page does not terminate the native shell or jobs. Keep the
companion running and the computer awake. Ctrl+C **in the browser terminal**
interrupts its foreground command. Ctrl+C **in the terminal running the
companion** stops the service and its shell. Reconnection replays output, not
commands; output older than the bounded replay buffer can be omitted with a
notice. Only one browser client controls a companion at a time.

Normal live GLVis delivery retains the latest complete frames when the viewer
falls behind, so a hidden page does not throttle the solver. Intermediate live
frames can be skipped. Explicit solver pauses and the Pause/Step controls still
pause visualization processing. Browser recording captures delivered frames;
it is not a lossless native recording of skipped frames.

Full workspace import/export carries portable source/data/Git content, recorded
deletions and the existing saved-session state. Cross-mode imports preserve the destination's
compiler configuration and build products; machine-specific executables,
generated configuration, caches and Git execution controls are omitted, with a
notice. Archive timestamps can predate retained binaries: use `make -B ex1`
(or the affected target) after import, and force-rebuild the MFEM library too
if its sources or headers changed. Exact GLVis cameras,
running processes and animation history are not archive state. Standalone Git
checkouts are supported; linked worktrees and escaping symlinks require making a
self-contained copy first.

The **Changes** panel can review native changes and export the same source patch.
Its **Reproduction** option adds a command, selected meshes, test notes and
optional terminal output. Patch generation does not run the checkout's Git
filters or hooks. Review a reproduction bundle before sharing it.

## Connection and platform scope

The companion serves the same interface at `http://127.0.0.1:PORT/`, with the UI
and API on one origin. The public GitHub Pages site has a **Local compute** button
with setup instructions and a download. It cannot launch a native process itself. The initial local
option does not require cross-origin access from the HTTPS GitHub page.

The service binds only to loopback, validates Host/Origin, pairs through a
one-use URL fragment and requires authenticated requests for files and terminal
access. Starting it grants its terminal the privileges of your local account;
the terminal is not a filesystem sandbox. Do not run it as administrator.
Stopping the companion revokes its connection credentials.

macOS is the tested native host. The POSIX backend also targets Linux and WSL;
those platforms require separate end-to-end validation. Windows requires WSL,
not a native Windows Python terminal. Phones and tablets keep using browser-only
compute: their loopback address is their own device, not your laptop. Access from
another device is a separate remote-compute feature and is not enabled here.

Port 19916 is reserved for the native GLVis relay. If another GLVis server owns
it, close that server or choose `--glvis-port` and explicitly configure your
solver to use the same port. Unmodified examples use 19916. No other process is
stopped automatically.

If pairing expires, the shell exits, or the helper stops, restart the companion
and open its new pairing link. Pending terminal input is never automatically
retried after a connection error. Check the terminal's actual state before
resending a command.
