# Local compute

Use the same Files, Editor, Terminal and GLVis interface with a separate process
running on your laptop. Files, Make, the compiler and MFEM solvers run natively.
The browser renders the interface and GLVis. This removes the emulated Linux
filesystem and CPU from the build path.

## Start with an existing checkout

Requirements: Python 3.12 or newer, Bash, Make, a C++17 compiler, and a configured,
built **serial** MFEM checkout with a static `libmfem.a` for the visualization
helpers. The browser renderer is bundled for MFEM 4.10.
Run from the unpacked workbench distribution:

```sh
python3.12 companion/serve.py --workspace /absolute/path/to/mfem --doctor
python3.12 companion/serve.py --workspace /absolute/path/to/mfem
```

The first start builds two small native visualization helpers using that
checkout's configuration and library. It leaves the checkout's configuration
alone. Open the printed one-use pairing link; the command normally opens it for
you. The link expires after ten minutes. Pairing is retained in an HttpOnly cookie
for the browser session. Reload the resulting localhost page to reconnect.

The default interface port is 8765; use `--port 0` for an automatically chosen
port or `--port NUMBER` to select another. `--no-browser` only prints the link.
`--state-dir PATH` changes where helpers and shell history are stored. The default
is a checkout-specific directory under `~/.mfem-web/`.

In the browser terminal:

```sh
make ex1
./ex1
```

The editor and terminal use the actual selected checkout. Logical editor paths
such as `/root/mfem/examples/ex1.cpp` refer to that checkout; the native terminal's
`pwd` shows its real host path. After changing library implementation files,
rebuild the library as you normally would:

```sh
make -C .. -j4
make ex1
./ex1
```

Use your normal native compiler cache, debugger and installed command-line tools.
The browser-specific `mfem-browser-build` compiler and emulated `mfem-build`
wrapper are not needed in local mode. Build timings depend on your native MFEM
configuration, compiler and hardware; compare them with the same commands in a
regular terminal.

## Start with MFEM 4.10

Create a separate checkout if your existing one uses MPI or another incompatible
configuration. Run these commands in a parent directory of your choosing:

```sh
git clone --branch v4.10 --depth 1 https://github.com/mfem/mfem.git mfem-local
cd mfem-local
make config MFEM_USE_MPI=NO MFEM_USE_METIS=NO
make -j4
```

Then run the companion from the unpacked distribution with the absolute path to
`mfem-local`. This initial library build is separate from subsequent example
builds. Existing configured Make checkouts are the first supported workflow;
arbitrary CMake build-directory discovery and MPI visualization are future work.

## Persistence and switching modes

Saved files persist on the host immediately. Unsaved editor drafts are saved in
this browser's IndexedDB, separately for each native checkout. Browser-only named
VM checkpoints are not used in local mode. Export remains the portable backup
for source and session state.

Local archive compression and validation run in the companion. Transfers stream
through the browser without expanding the archive into a large JavaScript buffer.
The expanded archive limit is 512 MiB; omit unneeded generated results or use a
shallow Git checkout if the full history exceeds it.

Closing or hiding the page does not terminate the native shell or jobs. Keep the
companion running and the computer awake. Ctrl+C **in the browser terminal**
interrupts its foreground command. Ctrl+C **in the terminal running the
companion** stops the service and its shell. Reconnection replays output, not
commands; output older than the bounded replay buffer can be omitted with a
notice. Only one browser client controls a companion at a time.

Normal live GLVis delivery retains the latest complete frames when the viewer
falls behind, so a hidden page does not throttle the solver. Intermediate live
frames can be skipped. Explicit solver pauses and the Pause/Step controls still
pause visualization processing. Browser recording captures delivered frames;
it is not a lossless native recording of skipped frames.

Import/export carries portable source/data/Git content, recorded deletions and
the existing saved-session state. Cross-mode imports preserve the destination's
compiler configuration and build products; machine-specific executables,
generated configuration, caches and Git execution controls are omitted, with a
notice. Archive timestamps can predate retained binaries: use `make -B ex1`
(or the affected target) after import, and force-rebuild the MFEM library too
if its sources or headers changed. Exact GLVis cameras,
running processes and animation history are not archive state. Standalone Git
checkouts are supported; linked worktrees and escaping symlinks require making a
self-contained copy first.

The Changes panel can review native changes. Automatic patch/reproduction bundles
are unavailable in local mode; use Export workspace or your normal terminal Git
commands. This avoids running Git clean filters as a side effect of an automatic
browser operation.

## Connection and platform scope

The companion serves the same interface at `http://127.0.0.1:PORT/`, with the UI
and API on one origin. The public GitHub Pages site has a **Compute** dialog with
setup instructions. It cannot launch a native process itself. The initial local
option does not require cross-origin access from the HTTPS GitHub page.

The service binds only to loopback, validates Host/Origin, pairs through a
one-use URL fragment and requires authenticated requests for files and terminal
access. Starting it grants its terminal the privileges of your local account;
the terminal is not a filesystem sandbox. Do not run it as administrator.
Stopping the companion revokes its connection credentials.

macOS is the tested native host. The POSIX backend also targets Linux and WSL;
those platforms require separate end-to-end validation. Windows requires WSL,
not a native Windows Python terminal. Phones and tablets keep using browser-only
compute: their loopback address is their own device, not your laptop. Access from
another device is a separate remote-compute feature and is not enabled here.

Port 19916 is reserved for the native GLVis relay. If another GLVis server owns
it, close that server or choose `--glvis-port` and explicitly configure your
solver to use the same port. Unmodified examples use 19916. No other process is
stopped automatically.

If pairing expires, the shell exits, or the helper stops, restart the companion
and open its new pairing link. Pending terminal input is never automatically
retried after a connection error. Check the terminal's actual state before
resending a command.
