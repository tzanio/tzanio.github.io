MFEM local compute

Read LOCAL_COMPUTE.md for setup, requirements and platform limitations.
Requires Python 3.12+, Bash, Make, a C++17 compiler, and a serial or MPI MFEM
4.10 checkout configured and built with Make. Its static libmfem.a is
required for the visualization helpers.

MPI checkouts also need their MPI launcher and configured dependencies.
Use make ex1p and mpirun -np 2 ./ex1p in the browser terminal.
Run one visualizing MPI job at a time; no X11 or xterm is needed.

From this directory:
  python3.12 companion/serve.py --workspace /absolute/path/to/mfem

Open the pairing URL printed by the companion. The native terminal runs
as your local account. Keep the companion running while you work.

Browser-only version: https://tzanio.github.io/mfem/
