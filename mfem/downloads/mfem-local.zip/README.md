MFEM local compute

Read LOCAL_COMPUTE.md for setup, requirements and platform limitations.
Requires Python 3.12+, Bash, Make, a C++17 compiler, and a serial MFEM
4.10 checkout configured and built with Make. Its static libmfem.a is
required for the visualization helpers.

From this directory:
  python3.12 companion/serve.py --workspace /absolute/path/to/mfem

Open the pairing URL printed by the companion. The native terminal runs
as your local account. Keep the companion running while you work.

Browser-only version: https://tzanio.github.io/mfem/
