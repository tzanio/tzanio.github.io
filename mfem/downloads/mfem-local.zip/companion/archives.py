"""Portable source/session archives for the optional local MFEM companion.

No native configuration or executable is replaced by a browser archive. Native
exports use an explicit source inventory so browser imports can apply deletions
while retaining the destination compiler configuration and executable outputs.
"""
from pathlib import Path
import hashlib
import importlib.util
import io
import json
import os
import sys
import tarfile
import tempfile
import threading
import unicodedata

GUEST = Path(__file__).resolve().parents[1] / 'guest'
if str(GUEST) not in sys.path:
    sys.path.insert(0, str(GUEST))
_spec = importlib.util.spec_from_file_location('mfem_archive_bridge', GUEST / 'studio-bridge.py')
bridge = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(bridge)


def _progress(*args, **kwargs):
    pass


class NativeArchives:
    def __init__(self, root, temp_dir, baseline_path=None):
        self.root = Path(root).resolve()
        self.temp_dir = Path(temp_dir).resolve()
        self.temp_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.lock = threading.RLock()
        self.warnings = []
        self.baseline_path = Path(baseline_path) if baseline_path else None
        self._base = None
        git = self.root / '.git'
        if git.exists() and (not git.is_dir() or git.is_symlink()):
            raise ValueError('Local archives require a standalone checkout; linked Git worktrees are not supported')

    def _owned(self, path):
        value = Path(path).resolve()
        try:
            value.relative_to(self.temp_dir)
        except ValueError:
            raise ValueError('Archive temporary files must belong to this companion') from None
        if not value.is_file():
            raise ValueError('Archive temporary file is missing')
        return value

    def _snapshot(self, data, prefix='session'):
        descriptor, path = tempfile.mkstemp(prefix=prefix + '-', dir=self.temp_dir)
        with os.fdopen(descriptor, 'wb') as output:
            output.write(data)
        return path

    def _baseline(self):
        if self._base is not None:
            return self._base
        path = self.baseline_path
        if path is None:
            site = Path(__file__).resolve().parents[1] / 'site'
            try:
                entries = json.loads((site / 'vm/fs.json').read_text())['fsroot']
                for name in 'usr/local/share/mfem-workspace-base.json'.split('/'):
                    node = next(node for node in entries if node[0] == name)
                    entries = node[6]
                path = site / 'vm/fs' / node[6]
            except (OSError, ValueError, KeyError, StopIteration):
                raise ValueError('This browser backup needs the matching packaged MFEM base manifest') from None
        self._base = json.loads(path.read_text())
        return self._base

    def inspect(self, upload, progress=_progress):
        with self.lock:
            return bridge.inspect_session_archive(str(self._owned(upload)), progress, self._snapshot)

    def export(self, session_upload=None, compression='gzip', max_bytes=None, progress=_progress):
        if compression not in ('gzip', 'none'):
            raise ValueError('Unsupported workspace archive compression')
        maximum = 512 * 1024 * 1024 if max_bytes is None else max_bytes
        if type(maximum) is not int or not 0 < maximum <= 512 * 1024 * 1024:
            raise ValueError('Invalid archive size limit')
        with self.lock:
            self.warnings = []
            for name in ('alternates', 'http-alternates'):
                path = self.root / '.git/objects/info' / name
                if path.exists() and path.stat().st_size:
                    raise ValueError('Git object alternates are not portable. Use a self-contained clone without object alternates before exporting this workspace.')
            session = None
            if session_upload:
                with self._owned(session_upload).open('rb') as source:
                    session = bridge.session_metadata(source.read(32 * 1024 * 1024 + 1))
            progress('scanning', unit='files')
            nodes, protected = bridge.portable_scan(str(self.root))
            descriptor, output = tempfile.mkstemp(prefix='mfem-portable-', suffix='.tar.gz' if compression == 'gzip' else '.tar', dir=self.temp_dir)
            os.close(descriptor)
            try:
                options = {'compresslevel': 1} if compression == 'gzip' else {}
                with tarfile.open(output, 'w:gz' if compression == 'gzip' else 'w', **options) as archive:
                    entries = [(self.root, archive.gettarinfo(self.root, arcname='mfem'))]
                    skipped = []
                    for name in sorted(nodes):
                        if bridge.portable_protected(name, protected):
                            skipped.append(name)
                            continue
                        info = archive.gettarinfo(self.root / name, arcname='mfem/' + name)
                        if info is None:
                            raise ValueError('Unsupported workspace entry: ' + name)
                        entries.append((self.root / name, info))
                    bridge.validate_workspace_members([info for _, info in entries], str(self.root))
                    manifest = {'format': 'mfem-portable-workspace-v1', 'inventory': [info.name[5:] for _, info in entries if info.name != 'mfem'],
                                'omitted_count': len(skipped), 'producer': 'native'}
                    self.warnings = ['Portable archive omits %d build/configuration/Git-control entries. The destination keeps its own compiler configuration; rebuild affected targets explicitly after import.' % len(skipped)]
                    metadata = [('.mfem-portable.json', json.dumps(manifest, separators=(',', ':')).encode())]
                    if session is not None:
                        metadata.append(('mfem-workbench-session.json', session))
                    meta_entries = []
                    for name, data in metadata:
                        info = tarfile.TarInfo(name);info.size = len(data);info.mode = 0o600
                        meta_entries.append((info, data))
                    raw_size = 1024
                    for info in [info for _, info in entries] + [info for info, _ in meta_entries]:
                        raw_size += len(info.tobuf(archive.format, archive.encoding, archive.errors)) + ((info.size + 511) // 512) * 512
                    if ((raw_size + 10239) // 10240) * 10240 > maximum:
                        raise ValueError('Archive exceeds this device\'s %g MiB limit; remove unneeded results and export again' % (maximum / 1048576))
                    total = sum(info.size for _, info in entries if info.isfile()) + sum(len(data) for _, data in meta_entries)
                    completed = 0
                    progress('packing', 0, total)
                    def packed(size):
                        nonlocal completed
                        completed += size
                        progress('packing', completed, total)
                    for info, data in meta_entries:
                        archive.addfile(info, bridge.ProgressReader(io.BytesIO(data), packed))
                    for path, info in entries:
                        if info.isfile():
                            with path.open('rb') as source:
                                archive.addfile(info, bridge.ProgressReader(source, packed))
                        else:
                            archive.addfile(info)
                    progress('packing', completed, total, final=True)
                return output
            except Exception:
                Path(output).unlink(missing_ok=True)
                raise

    def restore(self, upload, expected_session_hash=None, progress=_progress):
        upload = self._owned(upload)
        with self.lock:
            try:
                progress('validating', 0, upload.stat().st_size)
                with tarfile.open(upload, 'r:*') as archive:
                    members = bridge.archive_members(archive)
                    session = bridge.archive_session_metadata(archive, members)
                    actual = hashlib.sha256(session).hexdigest() if session is not None else None
                    if actual != expected_session_hash:
                        raise ValueError('Session metadata changed after validation; import the archive again')
                    members = [item for item in members if item.name != 'mfem-workbench-session.json']
                    if sys.platform == 'darwin':
                        names = {}
                        for item in members:
                            key = unicodedata.normalize('NFD', item.name).casefold()
                            if key in names and names[key] != item.name:
                                raise ValueError('Archive paths differ only by case or Unicode normalization; rename them before importing on macOS')
                            names[key] = item.name
                    if any(item.name == '.mfem-checkpoint.json' for item in members):
                        raise ValueError('Saved browser checkpoints need their original browser workspace. Export its full workspace archive for local compute.')
                    markers = [item for item in members if item.name in ('.mfem-portable.json', '.mfem-workspace.json')]
                    known_builds, overlay = set(), not markers
                    if markers:
                        marker = markers[0]
                        if len(markers) != 1 or not marker.isfile() or marker.size > 16 * 1024 * 1024:
                            raise ValueError('Invalid portable workspace metadata')
                        manifest = json.loads(archive.extractfile(marker).read())
                        if not isinstance(manifest, dict):
                            raise ValueError('Invalid portable workspace metadata')
                        if marker.name == '.mfem-workspace.json':
                            base = self._baseline()
                            if manifest.get('format') != 'mfem-browser-workspace-v2' or manifest.get('base_id') != base['base_id']:
                                raise ValueError('This browser backup requires its matching packaged MFEM base. Use the local companion from the same workbench release as this backup.')
                            known_builds = {name for name, entry in base['entries'].items() if entry.get('build')}
                        elif manifest.get('format') != 'mfem-portable-workspace-v1':
                            raise ValueError('Unsupported portable workspace format')
                        members = [item for item in members if item is not marker]
                    else:
                        # Legacy archives are overlays. Include current paths in
                        # their inventory so unmentioned files are preserved.
                        converted = bridge.validate_workspace_members(members, str(self.root))
                        nodes, _ = bridge.portable_scan(str(self.root))
                        inventory = set(nodes) | {item.name for item in converted if item.name != '.'}
                        for name in list(inventory):
                            parent = Path(name).parent
                            while str(parent) != '.':
                                inventory.add(str(parent));parent = parent.parent
                        manifest = {'format': 'mfem-portable-workspace-v1', 'inventory': sorted(inventory), 'legacy_overlay': True}
                    warnings = bridge.restore_portable_archive(archive, members, manifest, str(self.root), progress, known_builds, overlay=overlay)
                    warnings.append('Imported source timestamps may predate retained binaries. Use make -B for affected targets; rebuild the MFEM library too if its sources or headers changed.')
                    result = {'restored': True, 'warnings': warnings}
                    if session is not None:
                        result['session_path'] = self._snapshot(session)
                    return result
            finally:
                upload.unlink(missing_ok=True)
