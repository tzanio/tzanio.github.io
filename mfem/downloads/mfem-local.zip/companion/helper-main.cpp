// Native-only entry point: MPI-configured MFEM helpers need their own singleton
// MPI runtime even when the incoming scene is serial. Guest helpers are unchanged.
#define main mfem_workbench_helper_main
#include MFEM_HELPER_SOURCE
#undef main

int main(int argc, char **argv)
{
#ifdef MFEM_USE_MPI
   mfem::Mpi::Init(argc, argv);
#endif
#ifdef MFEM_HELPER_WITH_ARGS
   return mfem_workbench_helper_main(argc, argv);
#else
   return mfem_workbench_helper_main();
#endif
}
