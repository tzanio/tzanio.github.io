"""Native GLVis relay: bounded newest-frame delivery, independent of UI speed."""
import pathlib
import sys
import threading

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / 'guest'))
from glvis_socket import Channel, Visualizations


class NativeChannel(Channel):
    def deliver(self, data):
        self.wait_play()
        self.frame += 1
        self.manager.frame(self.number, self.frame, bytes(data))


class NativeVisualizations(Visualizations):
    def __init__(self, emit, snapshot, helper):
        self.output = emit
        self.states = {}
        self.retired = {}
        self.delivery_lock = threading.RLock()
        super().__init__(self.event, snapshot, helper)

    def state(self, number):
        if number not in self.states:
            # Retain the eight most recent completed scenes for reconnect.
            completed = [key for key, item in self.states.items() if item['ended']]
            while len(self.states) >= 8 and completed:
                self.discard(completed.pop(0))
            self.states[number] = {'current': None, 'pending': None, 'last': None,
                                   'ended': None, 'commands': []}
        return self.states[number]

    def discard(self, number):
        state = self.states.pop(number, None)
        if state and state['current']:
            pathlib.Path(state['current']).unlink(missing_ok=True)

    def send_frame(self, number, item):
        state = self.states[number]
        frame, data, commands = item
        path = self.snapshot(data, 'view')
        state['current'], state['last'] = path, item
        self.output({'event': 'glvis', 'client': number, 'frame': frame, 'path': path})
        for command in commands:
            if state['ended'] and command.get('command') in ('pause', 'autopause'):
                continue
            self.output(command)

    def frame(self, number, frame, data):
        with self.delivery_lock:
            state = self.state(number)
            item = (frame, data, list(state['pending'][2]) if state['pending'] else [])
            if state['current']:
                # The pending snapshot has never been exposed to the browser,
                # so replacing it cannot change a frame being read/rendered.
                state['pending'] = item
            else:
                self.send_frame(number, item)

    def event(self, event):
        if event.get('event') not in ('glvis-command', 'glvis-end'):
            self.output(event)
            return
        with self.delivery_lock:
            state = self.state(event['client'])
            if event['event'] == 'glvis-end':
                state['ended'] = event
                if not state['pending']:
                    self.output(event)
            elif state['pending']:
                # Commands belong to the pending frame. Explicit pause is
                # delivered when that frame can be displayed; solver waits.
                self.remember(state['pending'][2], event)
            else:
                if state['last']:
                    self.remember(state['last'][2], event)
                self.output(event)

    @staticmethod
    def remember(commands, event):
        # Most protocol commands set a value. Preserve their latest value while
        # retaining the order of non-idempotent key sequences and pauses.
        if event['command'] not in ('keys', 'pause', 'screenshot'):
            commands[:] = [item for item in commands if item['command'] != event['command']]
        commands.append(event)
        if len(commands) > 256 or sum(len(str(item)) for item in commands) > 65536:
            raise ValueError('Too many GLVis commands between displayed frames; reconnect the viewer')

    def acknowledge(self, path):
        with self.delivery_lock:
            self.retired.pop(path, None)
            for number, state in self.states.items():
                if state['current'] != path:
                    continue
                state['current'] = None
                if state['pending']:
                    item, state['pending'] = state['pending'], None
                    self.send_frame(number, item)
                elif state['ended']:
                    self.output(state['ended'])
                break

    def reconnect(self):
        import time
        with self.delivery_lock:
            for path, deadline in list(self.retired.items()):
                if deadline < time.monotonic():
                    pathlib.Path(path).unlink(missing_ok=True)
                    del self.retired[path]
            for number, state in self.states.items():
                item = state['pending'] or state['last']
                if not item:
                    continue
                if state['current']:
                    # An old page may still be finishing an already-started
                    # fetch. Exposed snapshots remain immutable until ACK/TTL.
                    self.retired[state['current']] = time.monotonic() + 120
                state['current'], state['pending'] = None, None
                self.send_frame(number, item)
                if state['ended']:
                    self.output(state['ended'])

    def serve(self, connection, number):
        if not self.slots.acquire(blocking=False):
            connection.close()
            self.output({'event': 'error', 'error': 'At most eight GLVis connections can be active.'})
            return
        channel = NativeChannel(self, connection, number)
        with self.lock:
            self.channels[number] = channel
        try:
            channel.run()
        except Exception as error:
            if not channel.cancelled.is_set():
                self.output({'event': 'error', 'client': number, 'error': 'GLVis: ' + str(error)})
        finally:
            channel.cancel()
            with self.lock:
                self.channels.pop(number, None)
            self.slots.release()
            self.event({'event': 'glvis-end', 'client': number, 'frames': channel.frame})
