"""Native GLVis relay: bounded newest-frame delivery, independent of UI speed."""
import pathlib
import json
import re
import socket
import subprocess
import sys
import threading
import time

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / 'guest'))
from glvis_socket import Channel, Visualizations, records


class NativeChannel(Channel):
    def deliver(self, data):
        self.wait_play()
        self.frame += 1
        self.manager.frame(self.number, self.frame, bytes(data))


class ParallelChannel(NativeChannel):
    def __init__(self, manager, connections, number):
        self.connections = connections
        super().__init__(manager, connections[0], number)

    def cancel(self):
        super().cancel()
        for connection in self.connections[1:]:
            try:
                connection.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            connection.close()

    def run(self):
        descriptors = [connection.fileno() for connection in self.connections]
        helper = pathlib.Path(self.manager.helper).with_name('studio-glvis-parallel')
        self.process = subprocess.Popen([str(helper), *map(str, descriptors)],
            pass_fds=descriptors, stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        errors = bytearray()
        def collect_errors():
            while data := self.process.stderr.read(4096):
                errors.extend(data); del errors[:-4096]
        reader = threading.Thread(target=collect_errors, daemon=True); reader.start()
        try:
            pause_before_frame = False
            for kind, data in records(self.process.stdout):
                if kind == b'F':
                    if pause_before_frame and (self.single_step or self.autopause):
                        self.pause()
                    self.deliver(data)
                    pause_before_frame = self.single_step or self.autopause
                else:
                    command = json.loads(data)
                    if command['command'] == 'pause':
                        self.pause(); pause_before_frame = False
                    else:
                        if command['command'] == 'autopause':
                            self.autopause = command['args'][0] not in ('0', 'off')
                            pause_before_frame = self.autopause or self.single_step
                        self.manager.emit({'event': 'glvis-command', 'client': self.number, **command})
            code = self.process.wait(timeout=5); reader.join(timeout=5)
            if code:
                raise ValueError(errors.decode('utf-8', 'replace').strip() or 'Parallel GLVis parser failed')
        finally:
            if self.process.poll() is None:
                self.process.terminate()
                try:
                    self.process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    self.process.kill(); self.process.wait()
            self.process.stdout.close(); reader.join(timeout=5); self.process.stderr.close()


class NativeVisualizations(Visualizations):
    def __init__(self, emit, snapshot, helper):
        self.output = emit
        self.states = {}
        self.retired = {}
        self.delivery_lock = threading.RLock()
        self.group_lock = threading.RLock()
        self.pending_group = None
        self.active_parallel = None
        self.group_timeout = 30
        super().__init__(self.event, snapshot, helper)

    def accept(self, connection, number):
        """Classify without consuming bytes needed by the native MFEM parser."""
        deadline = time.monotonic() + 30
        connection.settimeout(30)
        try:
            while True:
                data = connection.recv(256, socket.MSG_PEEK)
                if not data:
                    connection.close(); return
                token = re.match(rb'^\s*(\S+)\s', data)
                if token and token[1] != b'parallel':
                    connection.settimeout(None); return self.serve(connection, number)
                header = re.match(rb'^\s*parallel\s+(\d+)\s+(\d+)\s', data)
                if header:
                    count, rank = map(int, header.groups())
                    if not 1 <= count <= 64 or not 0 <= rank < count:
                        raise ValueError('Parallel GLVis supports 1–64 valid rank sockets')
                    connection.settimeout(None)
                    return self.join_parallel(connection, number, count, rank)
                if len(data) >= 256 or time.monotonic() >= deadline:
                    raise ValueError('Invalid or incomplete GLVis connection header')
                time.sleep(.01)
        except Exception as error:
            connection.close()
            self.output({'event': 'error', 'error': 'GLVis: ' + str(error)})

    def abandon_group(self, group, reason):
        with self.group_lock:
            if self.pending_group is not group:
                return
            self.pending_group = None
            group['timer'].cancel()
            for connection in group['connections'].values():
                connection.close()
            self.output({'event': 'error', 'error': reason})

    def join_parallel(self, connection, number, count, rank):
        with self.group_lock:
            if self.active_parallel is not None:
                connection.close()
                self.output({'event': 'error', 'error': 'An MPI visualization is already active. Run one MPI visualization job at a time.'})
                return
            group = self.pending_group
            if group and (group['count'] != count or rank in group['connections']):
                connection.close()
                self.abandon_group(group, 'Conflicting MPI rank connections were rejected. Run one MPI visualization job at a time and retry.')
                return
            if group is None:
                group = {'count': count, 'number': number, 'connections': {}}
                timer = threading.Timer(self.group_timeout, self.abandon_group, args=(group, 'Timed out waiting for every MPI visualization rank. Check the MPI job and retry.'))
                timer.daemon = True; group['timer'] = timer
                self.pending_group = group; timer.start()
            group['connections'][rank] = connection
            if len(group['connections']) < count:
                return
            group['timer'].cancel(); self.pending_group = None
            self.active_parallel = group['number']
            connections = [group['connections'][i] for i in range(count)]
        try:
            self.serve_parallel(connections, group['number'])
        finally:
            with self.group_lock:
                self.active_parallel = None

    def stop_pending(self):
        with self.group_lock:
            if self.pending_group:
                self.abandon_group(self.pending_group, 'Pending MPI visualization stopped.')

    def state(self, number):
        if number not in self.states:
            # Retain the eight most recent completed scenes for reconnect.
            completed = [key for key, item in self.states.items() if item['ended']]
            while len(self.states) >= 8 and completed:
                self.discard(completed.pop(0))
            self.states[number] = {'current': None, 'pending': None, 'last': None,
                                   'ended': None, 'commands': []}
        return self.states[number]

    def discard(self, number):
        state = self.states.pop(number, None)
        if state and state['current']:
            pathlib.Path(state['current']).unlink(missing_ok=True)

    def send_frame(self, number, item):
        state = self.states[number]
        frame, data, commands = item
        path = self.snapshot(data, 'view')
        state['current'], state['last'] = path, item
        self.output({'event': 'glvis', 'client': number, 'frame': frame, 'path': path})
        for command in commands:
            if state['ended'] and command.get('command') in ('pause', 'autopause'):
                continue
            self.output(command)

    def frame(self, number, frame, data):
        with self.delivery_lock:
            state = self.state(number)
            item = (frame, data, list(state['pending'][2]) if state['pending'] else [])
            if state['current']:
                # The pending snapshot has never been exposed to the browser,
                # so replacing it cannot change a frame being read/rendered.
                state['pending'] = item
            else:
                self.send_frame(number, item)

    def event(self, event):
        if event.get('event') not in ('glvis-command', 'glvis-end'):
            self.output(event)
            return
        with self.delivery_lock:
            state = self.state(event['client'])
            if event['event'] == 'glvis-end':
                state['ended'] = event
                if not state['pending']:
                    self.output(event)
            elif state['pending']:
                # Commands belong to the pending frame. Explicit pause is
                # delivered when that frame can be displayed; solver waits.
                self.remember(state['pending'][2], event)
            else:
                if state['last']:
                    self.remember(state['last'][2], event)
                self.output(event)

    @staticmethod
    def remember(commands, event):
        # Most protocol commands set a value. Preserve their latest value while
        # retaining the order of non-idempotent key sequences and pauses.
        if event['command'] not in ('keys', 'pause', 'screenshot'):
            commands[:] = [item for item in commands if item['command'] != event['command']]
        commands.append(event)
        if len(commands) > 256 or sum(len(str(item)) for item in commands) > 65536:
            raise ValueError('Too many GLVis commands between displayed frames; reconnect the viewer')

    def acknowledge(self, path):
        with self.delivery_lock:
            self.retired.pop(path, None)
            for number, state in self.states.items():
                if state['current'] != path:
                    continue
                state['current'] = None
                if state['pending']:
                    item, state['pending'] = state['pending'], None
                    self.send_frame(number, item)
                elif state['ended']:
                    self.output(state['ended'])
                break

    def reconnect(self):
        import time
        with self.delivery_lock:
            for path, deadline in list(self.retired.items()):
                if deadline < time.monotonic():
                    pathlib.Path(path).unlink(missing_ok=True)
                    del self.retired[path]
            for number, state in self.states.items():
                item = state['pending'] or state['last']
                if not item:
                    continue
                if state['current']:
                    # An old page may still be finishing an already-started
                    # fetch. Exposed snapshots remain immutable until ACK/TTL.
                    self.retired[state['current']] = time.monotonic() + 120
                state['current'], state['pending'] = None, None
                self.send_frame(number, item)
                if state['ended']:
                    self.output(state['ended'])

    def serve(self, connection, number):
        self.serve_channel(NativeChannel(self, connection, number))

    def serve_parallel(self, connections, number):
        self.serve_channel(ParallelChannel(self, connections, number))

    def serve_channel(self, channel):
        if not self.slots.acquire(blocking=False):
            channel.cancel()
            self.output({'event': 'error', 'error': 'At most eight GLVis connections can be active.'})
            return
        number = channel.number
        with self.lock:
            self.channels[number] = channel
        try:
            channel.run()
        except Exception as error:
            if not channel.cancelled.is_set():
                self.output({'event': 'error', 'client': number, 'error': 'GLVis: ' + str(error)})
        finally:
            channel.cancel()
            with self.lock:
                self.channels.pop(number, None)
            self.slots.release()
            self.event({'event': 'glvis-end', 'client': number, 'frames': channel.frame})
