// Assemble rank-aligned native GLVis streams into a serial browser scene.
// The Mesh/GridFunction piece constructors are the same MFEM interfaces used
// by GLVis StreamReader::ReadStreams. No MPI solver protocol is changed.
#define main unused_serial_protocol_main
#include "../guest/glvis-stream.cpp"
#undef main
#include <memory>
#include <sstream>

namespace
{
class RankBuffer : public std::streambuf
{
   int fd;
   char buffer[65536];
   size_t consumed = 0;
protected:
   int_type underflow() override
   {
      if (gptr() && gptr() != egptr()) { return traits_type::to_int_type(*gptr()); }
      ssize_t count;
      do { count = ::read(fd, buffer, sizeof(buffer)); } while (count < 0 && errno == EINTR);
      if (count < 0) { throw std::runtime_error(std::strerror(errno)); }
      if (!count) { return traits_type::eof(); }
      consumed += count;
      if (consumed > max_frame + sizeof(buffer))
      { throw std::length_error("A parallel rank frame exceeds 64 MiB"); }
      setg(buffer, buffer, buffer + count);
      return traits_type::to_int_type(*gptr());
   }
public:
   explicit RankBuffer(int descriptor) : fd(descriptor) { }
   void next() { consumed = egptr() && gptr() ? egptr() - gptr() : 0; }
};

const std::map<std::string, int> command_arity = {
   {"keys",1}, {"pause",0}, {"autopause",1}, {"window_title",1},
   {"window_size",2}, {"window_geometry",4}, {"view",2}, {"viewcenter",2},
   {"zoom",1}, {"shading",1}, {"subdivisions",2}, {"valuerange",2},
   {"autoscale",1}, {"levellines",3}, {"palette",1}, {"palette_repeat",1},
   {"palette_file",1}, {"palette_name",1}, {"camera",9}, {"plot_caption",1},
   {"axis_labels",3}, {"axis_numberformat",1}, {"colorbar_numberformat",1},
   {"screenshot",1}, {"fix_orientations",1}, {"save_coloring",1}, {"keep_attributes",1}
};

// Rank zero owns view commands; settings must agree on all ranks. Waiting for
// all rank payloads before assembly keeps time-dependent frames aligned.
std::string next_payload(std::istream &input, int rank, int count,
                         bool &fix_orientation, bool &keep_attributes)
{
   bool header = false;
   std::string token;
   while (input >> token)
   {
      if (token == "parallel")
      {
         int n, p;
         input >> n >> p;
         if (!input || header || n != count || p != rank)
         { throw std::runtime_error("Parallel GLVis rank/count changed between frames"); }
         header = true;
      }
      else if (token == "mesh" || token == "solution" || token == "quadrature")
      {
         if (!header) { throw std::runtime_error("Parallel frame is missing its rank header"); }
         return token;
      }
      else
      {
         auto found = command_arity.find(token);
         if (found == command_arity.end())
         { throw std::runtime_error("Unsupported parallel GLVis command: " + token); }
         const bool quoted = token == "window_title" || token == "plot_caption" ||
                             token == "axis_labels" || token == "axis_numberformat" ||
                             token == "colorbar_numberformat";
         std::vector<std::string> args;
         for (int i = 0; i < found->second; ++i) { args.push_back(argument(input, quoted)); }
         if (token == "fix_orientations")
         { fix_orientation = args[0] != "0" && args[0] != "off"; }
         else if (token == "keep_attributes")
         { keep_attributes = args[0] == "1" || args[0] == "on" || args[0] == "real"; }
         else if (rank == 0 && token != "save_coloring")
         {
            std::string json = "{\"command\":" + quote(token) + ",\"args\":[";
            for (size_t i = 0; i < args.size(); ++i)
            { if (i) { json += ','; } json += quote(args[i]); }
            send('C', json + "]}");
         }
      }
   }
   if (header) { throw std::runtime_error("Incomplete parallel GLVis frame"); }
   return "";
}
}

int main(int argc, char **argv)
{
#ifdef MFEM_USE_MPI
   mfem::Mpi::Init(argc, argv);
#endif
   mfem::out.SetStream(std::cerr);
   if (argc < 2 || argc > 65)
   { std::cerr << "Parallel GLVis requires 1–64 rank sockets\n"; return 1; }
   const int count = argc - 1;
   std::vector<std::unique_ptr<RankBuffer>> buffers;
   std::vector<std::unique_ptr<std::istream>> inputs;
   std::vector<bool> fix(count, true), keep(count, false);
   try
   {
      for (int i = 1; i < argc; ++i)
      {
         buffers.emplace_back(new RankBuffer(std::stoi(argv[i])));
         inputs.emplace_back(new std::istream(buffers.back().get()));
         inputs.back()->exceptions(std::ios::badbit);
      }
      while (true)
      {
         std::vector<std::unique_ptr<mfem::Mesh>> owned_meshes;
         std::vector<std::unique_ptr<mfem::GridFunction>> owned_fields;
         std::vector<std::unique_ptr<mfem::ComplexGridFunction>> owned_complex;
         std::vector<std::unique_ptr<mfem::QuadratureFunction>> owned_quadrature;
         std::vector<mfem::Mesh*> meshes;
         std::vector<mfem::GridFunction*> fields, real_parts, imag_parts;
         std::vector<mfem::QuadratureFunction*> quadrature;
         std::string kind;
         bool finished = false, complex = false;
         for (int rank = 0; rank < count; ++rank)
         {
            buffers[rank]->next();
            bool orientation = fix[rank], attributes = keep[rank];
            const auto current = next_payload(*inputs[rank], rank, count, orientation, attributes);
            fix[rank] = orientation; keep[rank] = attributes;
            if (rank == 0) { kind = current; finished = current.empty(); }
            if (current != kind || orientation != fix[0] || attributes != keep[0])
            { throw std::runtime_error("Parallel ranks ended early or supplied incompatible scene data/settings"); }
            if (finished) { continue; }
            auto &input = *inputs[rank];
            owned_meshes.emplace_back(new mfem::Mesh(input, 1, 0, orientation));
            auto *mesh = owned_meshes.back().get();
            meshes.push_back(mesh);
            if (!attributes)
            {
               for (int i = 0; i < mesh->GetNE(); ++i) { mesh->GetElement(i)->SetAttribute(rank+1); }
               for (int i = 0; i < mesh->GetNBE(); ++i) { mesh->GetBdrElement(i)->SetAttribute(rank+1); }
            }
            if (kind == "solution")
            {
               input >> std::ws;
               const bool current_complex = input.peek() == 'P' || input.peek() == 'C';
               if (rank == 0) { complex = current_complex; }
               if (complex != current_complex)
               { throw std::runtime_error("Parallel ranks mixed real and complex fields"); }
               if (complex)
               {
                  if (input.peek() == 'P') { input.ignore(3); }
                  owned_complex.emplace_back(new mfem::ComplexGridFunction(mesh, input));
                  real_parts.push_back(&owned_complex.back()->real());
                  imag_parts.push_back(&owned_complex.back()->imag());
               }
               else
               {
                  owned_fields.emplace_back(new mfem::GridFunction(mesh, input));
                  fields.push_back(owned_fields.back().get());
               }
            }
            else if (kind == "quadrature")
            {
               owned_quadrature.emplace_back(new mfem::QuadratureFunction(mesh, input));
               quadrature.push_back(owned_quadrature.back().get());
            }
            if (!input) { throw std::runtime_error("Incomplete parallel mesh/field"); }
         }
         if (finished) { return 0; }
         mfem::Mesh mesh(meshes.data(), count);
         std::ostringstream output;
         output.precision(17);
         output << kind << '\n'; mesh.Print(output);
         if (kind == "solution" && !complex)
         {
            mfem::GridFunction field(&mesh, fields.data(), count); field.Save(output);
         }
         else if (kind == "solution")
         {
            mfem::GridFunction real(&mesh, real_parts.data(), count);
            mfem::GridFunction imag(&mesh, imag_parts.data(), count);
            mfem::ComplexGridFunction field(real.FESpace());
            field.real() = real; field.imag() = imag; field.Save(output);
         }
         else if (kind == "quadrature")
         {
            if (meshes[0]->GetNE() == 0)
            { throw std::runtime_error("Quadrature assembly requires nonempty rank partitions"); }
            mfem::QuadratureSpace space(mesh, quadrature[0]->GetIntRule(0));
            mfem::QuadratureFunction field(space, quadrature[0]->GetVDim());
            int offset = 0;
            for (const auto *part : quadrature)
            {
               if (part->GetVDim() != field.GetVDim() || offset + part->Size() > field.Size())
               { throw std::runtime_error("Parallel quadrature spaces do not match"); }
               std::memcpy(field.GetData() + offset, part->GetData(), part->Size() * sizeof(mfem::real_t));
               offset += part->Size();
            }
            if (offset != field.Size()) { throw std::runtime_error("Incomplete parallel quadrature data"); }
            field.Save(output);
         }
         send('F', output.str());
      }
   }
   catch (const std::exception &error)
   { std::cerr << "Parallel GLVis: " << error.what() << '\n'; return 1; }
}
