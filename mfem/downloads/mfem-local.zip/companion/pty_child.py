"""Acquire a controlling terminal in a fresh interpreter, then exec Bash."""
import fcntl
import os
import sys
import termios

slave = int(sys.argv[1])
os.setsid()
fcntl.ioctl(slave, termios.TIOCSCTTY, 0)
for descriptor in (0, 1, 2):
    os.dup2(slave, descriptor)
if slave > 2:
    os.close(slave)
os.execv(sys.argv[2], [sys.argv[2], '--noprofile', '--rcfile', sys.argv[3], '-i'])
