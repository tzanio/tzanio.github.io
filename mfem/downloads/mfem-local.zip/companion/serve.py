#!/usr/bin/env python3
"""Optional local MFEM compute companion (Python 3.12+, macOS/Linux/WSL)."""
import argparse
import base64
from collections import deque
import hashlib
import hmac
import http.cookies
import http.server
import json
import mimetypes
import os
from pathlib import Path
import platform
import re
import secrets
import shlex
import shutil
import signal
import socket
import struct
import subprocess
import sys
import tempfile
import threading
import time
from urllib.parse import parse_qs, unquote, urlsplit
import webbrowser

HERE = Path(__file__).resolve().parent
APP = HERE.parent
VIRTUAL = '/root/mfem'
MAX_UPLOAD = 1024 * 1024 * 1024
sys.path.insert(0, str(APP / 'guest'))
from native_relay import NativeVisualizations


def json_bytes(value):
    return json.dumps(value, ensure_ascii=True, separators=(',', ':')).encode()


class Error(Exception):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status


def native_configuration(root):
    config = root / 'config/config.mk'
    if not config.is_file():
        raise Error('This checkout is not configured. Run make config and make in it first.')
    values = {}
    for line in config.read_text().splitlines():
        match = re.match(r'^(MFEM_[A-Z0-9_]+)\s*=\s*(.*)$', line)
        if match:
            values[match[1]] = match[2].strip()
    if values.get('MFEM_USE_MPI') == 'YES':
        raise Error('The first local release requires a serial MFEM build. Use a separate serial checkout; your MPI configuration has not been changed.')
    return values


def build_helpers(root, state):
    native_configuration(root)
    if not (root / 'libmfem.a').is_file():
        raise Error('Local visualization helpers require a configured static libmfem.a. Build the static serial library first; the checkout has not been changed.')
    destination = state / 'helpers'
    destination.mkdir(parents=True, exist_ok=True)
    # This is an explicit CLI setup action using the selected native checkout's
    # existing configuration. No user/global Makefiles or PATH are changed.
    escape = lambda value: str(value).replace('\\', '\\\\').replace(' ', '\\ ').replace('#', '\\#').replace('$', '$$')
    makefile = destination / 'helpers.mk'
    content = ('MFEM_DIR := ' + escape(root) + '\ninclude ' + escape(root / 'config/config.mk') + '\n' +
        '\nall: studio-glvis-stream studio-mesh-inspect\n' +
        '\nstudio-glvis-stream: ' + escape(APP / 'guest/glvis-stream.cpp') + ' $(MFEM_LIB_FILE) helpers.mk $(MFEM_DIR)/config/config.mk\n' +
        '\t$(MFEM_CXX) $(MFEM_FLAGS) "$<" "$(MFEM_DIR)/libmfem.a" $(MFEM_EXT_LIBS) -o "$@"\n' +
        '\nstudio-mesh-inspect: ' + escape(APP / 'guest/mesh-inspect.cpp') + ' $(MFEM_LIB_FILE) helpers.mk $(MFEM_DIR)/config/config.mk\n' +
        '\t$(MFEM_CXX) $(MFEM_FLAGS) "$<" "$(MFEM_DIR)/libmfem.a" $(MFEM_EXT_LIBS) -o "$@"\n')
    if not makefile.exists() or makefile.read_text() != content:
        makefile.write_text(content)
    subprocess.run(['make', '-f', str(makefile), 'all'], cwd=destination, check=True)
    return destination


class Companion:
    def __init__(self, root, state, helpers, visual_port=19916):
        self.root, self.state = root.resolve(), state.resolve()
        self.workspace_id = hashlib.sha256(str(self.root).encode()).hexdigest()[:24]
        self.configuration = native_configuration(self.root)
        self.temp = Path(tempfile.mkdtemp(prefix='session-', dir=self.state)).resolve()
        self.helpers = helpers
        self.events, self.event_bytes, self.sequence = deque(), 0, 0
        self.condition = threading.Condition()
        self.controller, self.controller_seen, self.controller_streams = None, 0, 0
        self.lease_lock = threading.Lock()
        self.rpc_lock, self.archive_lock = threading.Lock(), threading.Lock()
        self.rpc_ids, self.rpc_id_lock = {}, threading.Lock()
        self.stopped = threading.Event()
        self.visual_threads = []
        self.pair_token, self.cookie = secrets.token_urlsafe(32), secrets.token_urlsafe(32)
        self.pair_deadline, self.paired = time.monotonic() + 600, False
        self.terminal_decoder = None
        self.visual_port = visual_port
        self.visualizations = NativeVisualizations(self.emit, self.snapshot, str(helpers / 'studio-glvis-stream'))
        try:
            from archives import NativeArchives
            self.archives = NativeArchives(self.root, self.temp)
        except Exception:
            shutil.rmtree(self.temp, ignore_errors=True)
            raise
        self.visual_listener = socket.socket()
        self.visual_listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            self.visual_listener.bind(('127.0.0.1', visual_port))
            self.visual_listener.listen(8)
        except OSError as error:
            self.visual_listener.close()
            shutil.rmtree(self.temp, ignore_errors=True)
            if error.errno in (48, 98):
                raise Error('GLVis port ' + str(visual_port) + ' is in use. Stop the other GLVis listener, or choose --glvis-port and pass that port to your solver.') from None
            raise
        try:
            self.shell = self.start_shell()
        except Exception:
            self.visual_listener.close()
            shutil.rmtree(self.temp, ignore_errors=True)
            raise
        threading.Thread(target=self.read_terminal, daemon=True).start()
        threading.Thread(target=self.listen_visualizations, daemon=True).start()

    def path(self, value, *, temporary=False):
        if not isinstance(value, str) or '\0' in value:
            raise Error('Invalid file path')
        value = '/' + value.lstrip('/')
        if '..' in Path(value).parts:
            raise Error('File path must remain inside this workspace')
        if value == VIRTUAL or value.startswith(VIRTUAL + '/'):
            if temporary:
                raise Error('This operation requires a companion-owned temporary file')
            candidate = self.root / value[len(VIRTUAL):].lstrip('/')
            if not candidate.resolve().is_relative_to(self.root):
                raise Error('File link leaves this workspace')
            return candidate
        if value.startswith('/tmp/') and re.fullmatch(r'[A-Za-z0-9_.-]{1,180}', value[5:]):
            candidate = self.temp / value[5:]
            if not candidate.resolve().is_relative_to(self.temp):
                raise Error('Temporary file link leaves the session')
            return candidate
        raise Error('Files must be inside /root/mfem or this companion session')

    def virtual(self, value):
        if isinstance(value, Path):
            value = str(value)
        if isinstance(value, str):
            for root, virtual in ((self.root, VIRTUAL), (self.temp, '/tmp')):
                if value == str(root) or value.startswith(str(root) + '/'):
                    return virtual + value[len(str(root)):]
        if isinstance(value, dict):
            # History, source/diff text and labels are opaque data. Only path
            # fields contain native filesystem names to translate for the UI.
            return {key: item if key in ('history', 'text', 'detail', 'error', 'warnings', 'args', 'name', 'workspace') else self.virtual(item) for key, item in value.items()}
        if isinstance(value, list):
            return [self.virtual(item) for item in value]
        return value

    def snapshot(self, data, prefix='snapshot'):
        descriptor, name = tempfile.mkstemp(prefix=prefix + '-', dir=self.temp)
        with os.fdopen(descriptor, 'wb') as output:
            output.write(data)
        return name

    def publish(self, event):
        data = json_bytes(event)
        with self.condition:
            self.sequence += 1
            self.events.append((self.sequence, data))
            self.event_bytes += len(data)
            while self.event_bytes > 6 * 1024 * 1024 and len(self.events) > 1:
                _, discarded = self.events.popleft()
                self.event_bytes -= len(discarded)
            self.condition.notify_all()

    def emit(self, message):
        self.publish({'channel': 1, 'message': self.virtual(message)})

    def claim(self, client):
        if not isinstance(client, str) or not re.fullmatch(r'[A-Za-z0-9_-]{8,100}', client):
            raise Error('A valid browser client identity is required', 403)
        with self.lease_lock:
            if self.controller and self.controller != client and (
                    self.controller_streams or time.monotonic() - self.controller_seen < 30):
                raise Error('This companion is controlled by another browser tab. Close that tab and retry after 30 seconds.', 409)
            self.controller, self.controller_seen = client, time.monotonic()

    def info(self):
        return {'protocol': 1, 'workspace': str(self.root), 'workspaceId': self.workspace_id,
                'virtualRoot': VIRTUAL, 'platform': platform.system(),
                'mfemVersion': self.configuration.get('MFEM_VERSION_STRING', 'unknown'),
                'glvisPort': self.visual_port,
                'capabilities': {'files': True, 'terminal': True, 'visualization': True,
                                 'archives': True, 'inspection': True, 'changes': True,
                                 'reproduction': False, 'mpi': False}}

    def start_shell(self):
        import pty
        master, slave = pty.openpty()
        self.master = master
        rc = self.temp / 'bashrc'
        self.shell_cwd, self.history = self.temp / 'shell-cwd', self.state / 'history'
        self.restore_marker = self.temp / 'shell-restore'
        bin_dir = self.temp / 'bin'
        bin_dir.mkdir()
        (bin_dir / 'glvis').write_text('#!' + sys.executable + '\n' +
            (APP / 'guest/glvis').read_text().split('\n', 1)[1].replace("19916", str(self.visual_port)))
        (bin_dir / 'glvis').chmod(0o700)
        quote = shlex.quote
        rc.write_text('export TERM=xterm-256color COLORTERM=truecolor CLICOLOR=1\n' +
            'export HISTFILE=' + quote(str(self.history)) + '\n' +
            'export HISTCONTROL=ignoreboth:erasedups HISTSIZE=5000 HISTFILESIZE=10000\n' +
            'export MFEM_WORKSPACE=' + quote(str(self.root)) + '\n' +
            'export MFEM_DIR=' + quote(str(self.root)) + '\n' +
            'export MFEM_GLVIS_PORT=' + str(self.visual_port) + '\n' +
            'export PATH=' + quote(str(bin_dir)) + ':"$PATH"\n' +
            'shopt -s histappend checkwinsize\n' +
            ('alias ls="ls -G"\nalias ll="ls -alFG"\n' if sys.platform == 'darwin' else 'alias ls="ls --color=auto"\nalias ll="ls -alF --color=auto"\n') +
            "alias ..='cd ..'\nalias g=git\n" +
            '_mfem_prompt() {\n local status=$? request saved current logical\n' +
            ' if [[ -r ' + quote(str(self.restore_marker)) + ' ]]; then\n' +
            '  IFS= read -r request < ' + quote(str(self.restore_marker)) + '\n' +
            '  if [[ "$request" =~ ^shell-[a-zA-Z0-9_-]+$ && -f ' + quote(str(self.temp)) + '/"$request/history" ]]; then\n' +
            '   builtin history -c; builtin history -r ' + quote(str(self.temp)) + '/"$request/history"; builtin history -w\n' +
            '   IFS= read -r saved < ' + quote(str(self.temp)) + '/"$request/cwd"\n' +
            '   [[ -d "$saved" ]] && builtin cd -- "$saved"\n' +
            '   rm -f -- ' + quote(str(self.temp)) + '/"$request/history" ' + quote(str(self.temp)) + '/"$request/cwd" ' + quote(str(self.restore_marker)) + '\n' +
            '   rmdir -- ' + quote(str(self.temp)) + '/"$request"\n' +
            '  fi\n fi\n builtin history -a\n' +
            ' printf "%s\\n" "$PWD" > ' + quote(str(self.shell_cwd)) + '\n' +
            ' logical="$PWD"; if [[ "$PWD" == "$MFEM_WORKSPACE" || "$PWD" == "$MFEM_WORKSPACE/"* ]]; then logical="/root/mfem${PWD#"$MFEM_WORKSPACE"}"; fi\n' +
            ' printf "\\033]7;file://mfem%s\\007" "$logical"\n' +
            " PS1='\\n\\[\\e[1;38;5;114m\\]mfem\\[\\e[0m\\] \\[\\e[38;5;245m\\]•\\[\\e[0m\\] \\[\\e[38;5;117m\\]\\w\\[\\e[0m\\]'\n" +
            ' if (( status )); then PS1+=" \\[\\e[38;5;203m\\]exit ${status}\\[\\e[0m\\]"; fi\n' +
            " PS1+='\\n\\[\\e[38;5;114m\\]╰─\\[\\e[0m\\] $ '\n}\nPROMPT_COMMAND=_mfem_prompt\n" +
            '_mfem_make_complete() { local source targets="all clean test config help lib"; for source in *.cpp; do [[ -f "$source" ]] && targets="$targets ${source%.cpp}"; done; COMPREPLY=( $(compgen -W "$targets" -- "${COMP_WORDS[COMP_CWORD]}") ); }\n' +
            'complete -o default -F _mfem_make_complete make\n' +
            "complete -o default -W 'status diff add commit log show branch switch checkout restore reset tag stash help' git g\n")
        bash = shutil.which('bash') or '/bin/bash'
        process = subprocess.Popen([sys.executable, str(HERE / 'pty_child.py'), str(slave), bash, str(rc)],
                                   pass_fds=(slave,), cwd=self.root / 'examples' if (self.root / 'examples').is_dir() else self.root,
                                   env=dict(os.environ, BASH_SILENCE_DEPRECATION_WARNING='1'),
                                   stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        os.close(slave)
        return process

    def read_terminal(self):
        try:
            while not self.stopped.is_set():
                data = os.read(self.master, 16384)
                if not data:
                    break
                self.publish({'channel': 0, 'bytes': base64.b64encode(data).decode()})
        except OSError:
            pass
        if not self.stopped.is_set():
            self.emit({'event': 'error', 'error': 'The local shell has exited. Restart the companion to open a new terminal.'})

    def listen_visualizations(self):
        number = 0
        while not self.stopped.is_set():
            try:
                connection, _ = self.visual_listener.accept()
            except OSError:
                return
            number += 1
            thread = threading.Thread(target=self.visualizations.serve, args=(connection, number), daemon=True)
            self.visual_threads = [item for item in self.visual_threads if item.is_alive()]
            self.visual_threads.append(thread)
            thread.start()

    def progress(self, request):
        previous = [None, 0]
        def update(stage, completed=0, total=None, unit='bytes', detail='', final=False):
            now = time.monotonic()
            if final or stage != previous[0] or now - previous[1] > .15:
                self.emit({'event': 'operation-progress', 'id': request['id'], 'stage': stage,
                           'completed': completed, 'total': total, 'unit': unit, 'detail': detail})
                previous[:] = [stage, now]
        return update

    def shell_capture(self):
        cwd = self.shell_cwd.read_text().rstrip('\n') if self.shell_cwd.exists() else str(self.root / 'examples')
        history = self.history
        if self.restore_marker.exists():
            name = self.restore_marker.read_text().strip()
            if re.fullmatch(r'shell-[a-zA-Z0-9_-]+', name):
                stage = self.temp / name
                if (stage / 'history').exists():
                    history, cwd = stage / 'history', (stage / 'cwd').read_text().rstrip('\n')
        data = b''
        if history.exists():
            with history.open('rb') as source:
                source.seek(max(0, os.fstat(source.fileno()).st_size - 1024 * 1024))
                data = source.read()
        logical = self.virtual(cwd)
        if not logical.startswith(VIRTUAL):
            logical = VIRTUAL + '/examples'
        return {'cwd': logical, 'history': data.decode('utf-8', 'replace')}

    def shell_restore(self, request):
        cwd, history = request.get('cwd'), request.get('history')
        if not isinstance(history, str) or '\0' in history or len(history.encode()) > 1024 * 1024:
            raise Error('Invalid saved shell history')
        if not isinstance(cwd, str) or any(ord(char) < 32 or ord(char) == 127 for char in cwd):
            raise Error('Invalid saved shell directory')
        target = self.path(cwd)
        if not target.is_dir():
            target = self.root / 'examples'
        stage = Path(tempfile.mkdtemp(prefix='shell-', dir=self.temp))
        (stage / 'history').write_text(history)
        (stage / 'cwd').write_text(str(target) + '\n')
        marker = self.temp / ('marker-' + secrets.token_hex(8))
        marker.write_text(stage.name + '\n')
        os.replace(marker, self.restore_marker)
        return {'pending': True, 'cwd': self.virtual(target)}

    def safe_git(self, *args):
        env = {key: value for key, value in os.environ.items() if not key.startswith('GIT_')}
        env.update(GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL=os.devnull, GIT_OPTIONAL_LOCKS='0', GIT_NO_LAZY_FETCH='1')
        result = subprocess.run(['git', '-c', 'core.fsmonitor=false', '-c', 'core.hooksPath=' + os.devnull,
                                 '-c', 'diff.external=', '-c', 'core.attributesFile=' + os.devnull,
                                 '-C', str(self.root), *args], env=env, capture_output=True, timeout=30)
        if result.returncode:
            raise Error(result.stderr.decode('utf-8', 'replace').strip() or 'Git failed')
        return result.stdout

    def changes(self, request):
        if request['op'] in ('changes-export', 'reproduction-export'):
            raise Error('Use Export workspace in local mode. Automatic patch bundles are unavailable because Git clean filters can execute native programs.')
        if request['op'] == 'changes-diff':
            paths = []
            for value in request.get('paths', []):
                paths.append(str(self.path(value if value.startswith('/') else VIRTUAL + '/' + value).relative_to(self.root)))
            # --no-ext-diff and --no-textconv prevent external diff drivers.
            # Disabling filters additionally requires avoiding worktree Git diff
            # entirely; read blob contents through Git, compare with Python.
            import difflib
            tracked = self.safe_git('ls-files', '-z').decode('utf-8', 'surrogateescape').split('\0')
            chunks, total = [], 0
            for name in (paths or tracked):
                if not name or name.startswith('.git/'):
                    continue
                path = self.path(VIRTUAL + '/' + name)
                if path.is_symlink() or (path.exists() and (not path.is_file() or path.stat().st_size > 3 * 1024 * 1024)):
                    continue
                try:
                    before = self.safe_git('show', 'HEAD:' + name)
                except Error:
                    before = b''
                after = path.read_bytes() if path.exists() else b''
                if before == after:
                    continue
                if b'\0' in before + after:
                    chunk = 'Binary file changed: ' + name + '\n'
                else:
                    chunk = ''.join(difflib.unified_diff(before.decode('utf-8', 'replace').splitlines(True), after.decode('utf-8', 'replace').splitlines(True), fromfile='a/' + name, tofile='b/' + name))
                chunks.append(chunk); total += len(chunk.encode())
                if total > 1024 * 1024:
                    break
            return {'text': ''.join(chunks)[:1024 * 1024], 'truncated': total > 1024 * 1024, 'base_commit': self.safe_git('rev-parse', 'HEAD').decode().strip()}
        # `git status` invokes configured clean filters. Build an inexpensive
        # status from the index listing plus raw file/blob bytes instead.
        tracked = self.safe_git('ls-files', '--stage', '-z').split(b'\0')
        head_entries = {}
        for item in self.safe_git('ls-tree', '-r', '-z', 'HEAD').split(b'\0'):
            if item:
                meta, raw_name = item.split(b'\t', 1)
                mode, kind, oid = meta.split()
                if kind == b'blob':
                    head_entries[os.fsdecode(raw_name)] = (mode, oid)
        entries, names = [], set()
        for item in tracked:
            if not item:
                continue
            meta, raw_name = item.split(b'\t', 1)
            mode, oid, stage = meta.split()
            if stage != b'0':
                continue
            name = os.fsdecode(raw_name); names.add(name)
            prior = head_entries.get(name)
            staged = 'A' if prior is None else ('M' if prior != (mode, oid) else ' ')
            path = self.path(VIRTUAL + '/' + name)
            if not path.exists() and not path.is_symlink():
                entries.append({'status': staged + 'D', 'path': name}); continue
            if path.is_symlink():
                data = os.fsencode(os.readlink(path))
            elif path.is_file():
                data = path.read_bytes()
            else:
                continue
            actual = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
            executable = path.is_file() and bool(path.stat().st_mode & 0o111)
            mode_changed = mode in (b'100644', b'100755') and executable != (mode == b'100755')
            unstaged = 'M' if actual != oid.decode() or mode_changed else ' '
            if staged != ' ' or unstaged != ' ':
                entries.append({'status': staged + unstaged, 'path': name})
        entries.extend({'status': 'D ', 'path': name} for name in head_entries if name not in names)
        untracked = self.safe_git('ls-files', '--others', '--exclude-standard', '-z').split(b'\0')
        entries.extend({'status': '??', 'path': os.fsdecode(name)} for name in untracked if name)
        head = self.safe_git('rev-parse', 'HEAD').decode().strip()
        return {'base_commit': head, 'head': head, 'branch': self.safe_git('rev-parse', '--abbrev-ref', 'HEAD').decode().strip(), 'entries': entries}

    def rpc(self, request):
        op = request.get('op')
        if op == 'list' or op == 'list-many':
            def directory(value):
                path = self.path(value)
                result = []
                with os.scandir(path) as entries:
                    for entry in entries:
                        if entry.is_symlink() and not Path(entry.path).resolve().is_relative_to(self.root):
                            continue
                        result.append({'name': entry.name, 'dir': entry.is_dir()})
                return sorted(result, key=lambda entry: (not entry['dir'], entry['name']))
            if op == 'list':
                return directory(request.get('path', VIRTUAL))
            return {value: directory(value) if self.path(value).is_dir() else [] for value in request['paths']}
        if op == 'read':
            path = self.path(request['path'])
            if not path.exists():
                raise Error('No such file: ' + request['path'], 404)
            maximum = min(int(request.get('max_bytes', 64 * 1024 * 1024)), 64 * 1024 * 1024)
            if not path.is_file() or path.stat().st_size > maximum:
                raise Error('File is too large for the editor or is not a regular file')
            data = path.read_bytes()
            revision = hashlib.sha256(data).hexdigest()
            if request.get('metadata'):
                if request.get('if_revision') == revision:
                    return {'unchanged': True, 'revision': revision}
                return {'path': self.snapshot(data, 'read'), 'revision': revision, 'size': len(data)}
            return self.snapshot(data, 'read')
        if op == 'write':
            from importlib.machinery import SourceFileLoader
            path = self.path(request['path'])
            upload = self.path(request['upload'], temporary=True)
            with self.rpc_lock:
                # Guest function is pure and handles conflict checks and atomic
                # replacement without importing guest transport side effects.
                import importlib.util
                if not hasattr(self, '_bridge'):
                    spec = importlib.util.spec_from_file_location('native_bridge', APP / 'guest/studio-bridge.py')
                    self._bridge = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(self._bridge)
                return self._bridge.checked_write(str(path), str(upload), request.get('expected_hash'))
        if op == 'unlink':
            path = self.path(request['path'], temporary=True)
            path.unlink(missing_ok=True)
            self.visualizations.acknowledge(str(path))
            return True
        if op == 'resize':
            import fcntl, termios
            cols, rows = request.get('cols'), request.get('rows')
            if type(cols) is not int or type(rows) is not int or not 10 <= cols <= 1000 or not 2 <= rows <= 500:
                raise Error('Invalid terminal size')
            fcntl.ioctl(self.master, termios.TIOCSWINSZ, struct.pack('HHHH', rows, cols, 0, 0))
            return True
        if op in ('vis-play', 'vis-pause', 'vis-cancel'):
            return self.visualizations.control(request['client'], op, request.get('step', False))
        if op == 'session-shell-capture':
            return self.shell_capture()
        if op == 'session-shell-restore':
            return self.shell_restore(request)
        if op == 'mesh-inspect':
            path = self.path(request['path'], temporary=True)
            if path.stat().st_size > 64 * 1024 * 1024:
                raise Error('Inspection snapshot exceeds 64 MiB')
            command = [str(self.helpers / 'studio-mesh-inspect'), str(path)]
            point = request.get('point')
            if point is None:
                command.append('report')
            else:
                import math
                if not isinstance(point, list) or not 1 <= len(point) <= 3 or not all(type(value) in (int, float) and math.isfinite(value) for value in point):
                    raise Error('Provide one to three finite coordinates')
                command += ['probe', '--point', *map(str, point)]
            result = subprocess.run(command, capture_output=True, timeout=100)
            if result.returncode:
                raise Error(result.stderr[-3000:].decode('utf-8', 'replace') or 'Mesh inspection failed')
            return self.snapshot(result.stdout, 'inspection')
        if op in ('export', 'restore', 'session-inspect'):
            progress = self.progress(request)
            with self.archive_lock:
                if op == 'export':
                    uploaded = self.path(request['session_upload'], temporary=True) if request.get('session_upload') else None
                    path = self.archives.export(session_upload=uploaded, compression=request.get('compression', 'gzip'), max_bytes=request.get('max_bytes'), progress=progress)
                    return {'path': path, 'warnings': self.archives.warnings}
                upload = self.path(request['upload'], temporary=True)
                if op == 'session-inspect':
                    return self.archives.inspect(upload, progress=progress)
                return self.archives.restore(upload, expected_session_hash=request.get('expected_session_hash'), progress=progress)
        if op.startswith('changes-') or op == 'reproduction-export':
            return self.changes(request)
        raise Error('Operation is unavailable in local mode: ' + str(op))

    def run_rpc(self, request):
        try:
            response = {'id': request['id'], 'result': self.rpc(request)}
        except Exception as error:
            response = {'id': request.get('id'), 'error': str(error)}
        with self.rpc_id_lock:
            self.rpc_ids[request['id']]['response'] = response
        self.emit(response)

    def accept_rpc(self, request):
        signature = hashlib.sha256(json_bytes(request)).hexdigest()
        with self.rpc_id_lock:
            existing = self.rpc_ids.get(request['id'])
            if existing:
                if existing['signature'] != signature:
                    raise Error('RPC identity was reused with different input', 409)
                if existing['response'] is not None:
                    self.emit(existing['response'])
                return False
            # Never forget mutation identities during a companion session. This
            # prevents delayed duplicate write/import requests running twice.
            if len(self.rpc_ids) >= 100000:
                raise Error('This companion session has reached its request limit; restart it', 429)
            self.rpc_ids[request['id']] = {'signature': signature, 'response': None}
            return True

    def stop(self):
        self.stopped.set()
        self.visual_listener.close()
        with self.visualizations.lock:
            for channel in list(self.visualizations.channels.values()):
                channel.cancel()
        try:
            os.killpg(self.shell.pid, signal.SIGHUP)
        except ProcessLookupError:
            pass
        try:
            self.shell.wait(timeout=2)
        except subprocess.TimeoutExpired:
            os.killpg(self.shell.pid, signal.SIGTERM)
        os.close(self.master)
        with self.condition:
            self.condition.notify_all()
        for thread in self.visual_threads:
            thread.join(timeout=2)
        shutil.rmtree(self.temp, ignore_errors=True)


class Server(http.server.ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class Handler(http.server.BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    server_version = 'MFEM-local'

    @property
    def app(self):
        return self.server.app

    def log_message(self, *_args):
        # No pairing tokens, file paths or user shell data in access logs.
        pass

    def respond(self, status, body=b'', kind='application/json', headers=None):
        if isinstance(body, dict):
            body = json_bytes(body)
        self.response_headers(status, len(body), kind, headers)
        if self.command != 'HEAD':
            self.wfile.write(body)

    def response_headers(self, status, size, kind, headers=None):
        self.send_response(status)
        self.send_header('Content-Type', kind)
        self.send_header('Content-Length', str(size))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('X-Frame-Options', 'DENY')
        if status >= 400:
            self.send_header('Connection', 'close')
            self.close_connection = True
        for name, value in (headers or {}).items():
            self.send_header(name, value)
        self.end_headers()

    def respond_file(self, path, kind='application/octet-stream', headers=None):
        # Files may be hundreds of MiB. Keep HTTP buffers independent of archive
        # size, so the native process does not compete with GLVis/browser RAM.
        with path.open('rb') as source:
            size = os.fstat(source.fileno()).st_size
            self.response_headers(200, size, kind, headers)
            if self.command == 'HEAD':
                return
            remaining = size
            while remaining:
                data = source.read(min(1024 * 1024, remaining))
                if not data:
                    self.close_connection = True
                    raise ConnectionResetError('File changed during download')
                self.wfile.write(data)
                remaining -= len(data)

    def check_host(self):
        expected = '127.0.0.1:' + str(self.server.server_port)
        if self.headers.get('Host') != expected:
            raise Error('Unexpected host', 403)
        origin = self.headers.get('Origin')
        if origin is not None and origin != 'http://' + expected:
            raise Error('Unexpected origin', 403)
        if self.headers.get('Sec-Fetch-Site') not in (None, 'none', 'same-origin'):
            raise Error('Cross-site access is not allowed', 403)

    def authenticate(self, query, events=False):
        cookies = http.cookies.SimpleCookie()
        try:
            cookies.load(self.headers.get('Cookie', ''))
        except http.cookies.CookieError:
            raise Error('Open the pairing link printed by the companion', 401) from None
        actual = cookies.get('mfem_local_' + str(self.server.server_port))
        if not self.app.paired or not actual or not hmac.compare_digest(actual.value, self.app.cookie):
            raise Error('Open the pairing link printed by the companion', 401)
        if not events and self.headers.get('X-Workbench-Request') != '1':
            raise Error('Missing workbench request header', 403)
        client = query.get('client', [None])[0] if events else self.headers.get('X-Workbench-Client')
        self.app.claim(client)
        return client

    def content_length(self, limit):
        if self.headers.get('Transfer-Encoding'):
            raise Error('Chunked request bodies are not supported', 411)
        try:
            size = int(self.headers.get('Content-Length', '0'))
        except ValueError:
            raise Error('Invalid request length') from None
        if not 0 <= size <= limit:
            raise Error('Request exceeds the size limit', 413)
        self.connection.settimeout(60)
        return size

    def body(self, limit):
        size = self.content_length(limit)
        data = self.rfile.read(size)
        if len(data) != size:
            raise Error('Incomplete request body')
        return data

    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        try:
            self.check_host()
            url = urlsplit(self.path); query = parse_qs(url.query)
            if url.path.startswith('/api/'):
                client = self.authenticate(query, events=url.path == '/api/events')
                if url.path == '/api/session':
                    self.respond(200, self.app.info())
                elif url.path == '/api/file':
                    path = self.app.path(query.get('path', [''])[0])
                    if not path.is_file() or path.stat().st_size > MAX_UPLOAD:
                        raise Error('File is unavailable or exceeds 1 GiB', 404)
                    self.respond_file(path)
                elif url.path == '/api/events':
                    self.events(client, query)
                else:
                    raise Error('Unknown endpoint', 404)
                return
            self.static(url.path)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as error:
            self.respond(error.status if isinstance(error, Error) else 500, {'error': str(error)})

    def do_POST(self):
        try:
            self.check_host()
            url = urlsplit(self.path); query = parse_qs(url.query)
            if url.path == '/api/pair':
                if self.headers.get('X-Workbench-Request') != '1' or self.headers.get('Content-Type', '').split(';')[0] != 'application/json':
                    raise Error('Pairing requires a workbench JSON request', 403)
                request = json.loads(self.body(4096))
                token = request.get('token', '')
                if not isinstance(token, str) or self.app.paired or time.monotonic() > self.app.pair_deadline or not hmac.compare_digest(token, self.app.pair_token):
                    raise Error('Pairing link expired or already used. Restart the companion for a new link.', 401)
                self.app.paired = True
                self.respond(200, {'paired': True}, headers={'Set-Cookie': 'mfem_local_' + str(self.server.server_port) + '=' + self.app.cookie + '; HttpOnly; SameSite=Strict; Path=/'})
                return
            self.authenticate(query)
            if url.path == '/api/input':
                data = self.body(65536)
                if self.app.shell.poll() is not None:
                    raise Error('The local shell has exited', 409)
                with self.app.rpc_lock:
                    while data:
                        data = data[os.write(self.app.master, data):]
                self.respond(202, {'accepted': True})
            elif url.path == '/api/file':
                path = self.app.path(query.get('path', [''])[0], temporary=True)
                if not path.name.startswith('studio-upload-'):
                    raise Error('Uploads must use a new studio-upload temporary file')
                remaining = self.content_length(MAX_UPLOAD)
                created = False
                try:
                    with path.open('xb') as output:
                        created = True
                        while remaining:
                            data = self.rfile.read(min(1024 * 1024, remaining))
                            if not data:
                                raise Error('Incomplete uploaded file')
                            output.write(data)
                            remaining -= len(data)
                except Exception:
                    if created:
                        path.unlink(missing_ok=True)
                    raise
                self.respond(201, {'path': self.app.virtual(path)})
            elif url.path == '/api/rpc':
                request = json.loads(self.body(1024 * 1024 + 16384))
                if not isinstance(request, dict) or type(request.get('id')) is not int or not isinstance(request.get('op'), str):
                    raise Error('Invalid RPC request')
                accepted = self.app.accept_rpc(request)
                self.respond(202, {'accepted': True})
                if accepted:
                    threading.Thread(target=self.app.run_rpc, args=(request,), daemon=True).start()
            else:
                raise Error('Unknown endpoint', 404)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as error:
            self.respond(error.status if isinstance(error, Error) else 500, {'error': str(error)})

    def events(self, client, query):
        after = self.headers.get('Last-Event-ID') or query.get('after', ['0'])[0]
        try:
            sequence = max(0, int(after))
        except ValueError:
            raise Error('Invalid event cursor') from None
        self.connection.settimeout(20)
        self.send_response(200)
        self.send_header('Content-Type', 'text/event-stream')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Connection', 'close')
        self.end_headers()
        self.wfile.write(b': connected\n\n'); self.wfile.flush()
        with self.app.lease_lock:
            self.app.controller_streams += 1
        visual_floor = 0
        try:
            if sequence == 0:
                # Old visualization events describe already-consumed snapshots
                # and controls; send a fresh current scene on a page reload.
                visual_floor = self.app.sequence
                self.app.visualizations.reconnect()
            while not self.app.stopped.is_set():
                with self.app.condition:
                    events = [(number, data) for number, data in self.app.events if number > sequence]
                    if not events:
                        self.app.condition.wait(5)
                        events = [(number, data) for number, data in self.app.events if number > sequence]
                    first = self.app.events[0][0] if self.app.events else sequence + 1
                if sequence and sequence < first - 1:
                    gap = json_bytes({'channel': 1, 'message': {'event': 'transport-gap', 'message': 'Some terminal output expired while disconnected; the local shell is still running.'}})
                    self.wfile.write(b'data: ' + gap + b'\n\n')
                    visual_floor = self.app.sequence
                    self.app.visualizations.reconnect()
                    with self.app.condition:
                        events = [(number, data) for number, data in self.app.events if number > sequence]
                for number, data in events:
                    # Replayed frame events may reference snapshots already
                    # acknowledged by the old page. Current scenes were resent.
                    event = json.loads(data)
                    message = event.get('message', {})
                    if number <= visual_floor and message.get('event') in ('glvis', 'glvis-command', 'glvis-end'):
                        sequence = number
                        continue
                    if message.get('event') == 'glvis' and not self.app.path(message['path'], temporary=True).exists():
                        sequence = number
                        continue
                    self.wfile.write(b'id: ' + str(number).encode() + b'\ndata: ' + data + b'\n\n')
                    sequence = number
                self.wfile.write(b': heartbeat\n\n'); self.wfile.flush()
                self.app.claim(client)
        except (BrokenPipeError, ConnectionResetError, TimeoutError, OSError):
            pass
        finally:
            with self.app.lease_lock:
                self.app.controller_streams -= 1
                self.app.controller_seen = time.monotonic()
            self.close_connection = True

    def static(self, value):
        relative = unquote(value).lstrip('/') or 'index.html'
        path = (APP / 'site' / relative).resolve()
        if not path.is_relative_to((APP / 'site').resolve()) or not path.is_file() or path.name in ('offline-manifest.json',):
            raise Error('Not found', 404)
        # Never serve native source/output as origin scripts. Only packaged UI.
        content = None
        if path.name == 'index.html':
            content = path.read_bytes().replace(b'<head>', b'<head><script>window.WorkbenchLocalConfig={protocol:1};</script>', 1)
        mime = mimetypes.guess_type(path.name)[0] or 'application/octet-stream'
        # Bundled Emscripten GLVis creates its JS bindings with Function().
        headers = {'Content-Security-Policy': "default-src 'self' blob: data:; script-src 'self' 'unsafe-inline' 'unsafe-eval' 'wasm-unsafe-eval'; style-src 'self' 'unsafe-inline'; connect-src 'self'; worker-src 'self' blob:; frame-ancestors 'none'; object-src 'none'; base-uri 'self'"}
        if content is None:
            self.respond_file(path, mime, headers)
        else:
            self.respond(200, content, mime, headers)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', type=Path, required=True)
    parser.add_argument('--state-dir', type=Path)
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--glvis-port', type=int, default=19916)
    parser.add_argument('--no-browser', action='store_true')
    parser.add_argument('--doctor', action='store_true')
    parser.add_argument('--setup', action='store_true', help='Build native visualization helpers, then exit')
    args = parser.parse_args()
    if sys.version_info < (3, 12):
        parser.error('Python 3.12 or newer is required')
    root = args.workspace.expanduser().resolve()
    if not root.is_dir():
        parser.error('Workspace must be an existing MFEM checkout')
    state = (args.state_dir.expanduser().resolve() if args.state_dir else Path.home() / '.mfem-web' / hashlib.sha256(str(root).encode()).hexdigest()[:24])
    try:
        config = native_configuration(root)
        if args.doctor:
            print(json.dumps({'workspace': str(root), 'python': sys.version.split()[0], 'platform': platform.system(),
                              'make': shutil.which('make'), 'bash': shutil.which('bash'),
                              'mfem': config.get('MFEM_VERSION_STRING'), 'compiler': config.get('MFEM_CXX'),
                              'helpers': str(state / 'helpers')}, indent=2))
            return
        state.mkdir(parents=True, exist_ok=True, mode=0o700)
        helpers = build_helpers(root, state)
        if args.setup:
            print('Native helpers ready: ' + str(helpers))
            return
        server = Server(('127.0.0.1', args.port), Handler)
        try:
            app = Companion(root, state, helpers, args.glvis_port)
        except Exception:
            server.server_close()
            raise
        server.app = app
        url = 'http://127.0.0.1:' + str(server.server_port) + '/#pair=' + app.pair_token
        print('MFEM local compute: ' + str(root), flush=True)
        print('Open this one-use pairing link within 10 minutes:\n' + url, flush=True)
        print('Closing the browser keeps native jobs running. Ctrl+C here stops the companion.', flush=True)
        if not args.no_browser:
            webbrowser.open(url)
        try:
            server.serve_forever(poll_interval=.25)
        except KeyboardInterrupt:
            pass
        finally:
            app.stop(); server.server_close()
    except (Error, subprocess.CalledProcessError, OSError) as error:
        parser.exit(1, 'mfem-local: ' + str(error) + '\n')


if __name__ == '__main__':
    main()
