// Frame the native GLVis protocol using MFEM's readers, not TCP packet boundaries.
// stdin is a connected GLVis socket. stdout: <F|C> <byte count>\n<payload>.
// F contains one complete mesh/solution; C contains a JSON command description.
#include "mfem.hpp"
#include <unistd.h>
#include <cerrno>
#include <cstring>
#include <map>
#include <stdexcept>
#include <string>
#include <vector>

namespace
{
constexpr size_t max_frame = 64 * 1024 * 1024;

// Record only bytes consumed by MFEM. A read may contain part of the next frame;
// those bytes remain in the get area until the next parse. read(2), unlike a
// fixed-size istream::read, returns immediately when socket data is available.
class RecordingBuffer : public std::streambuf
{
   char buffer[65536];
   char *mark = nullptr;
   std::string consumed;

   void collect()
   {
      if (!mark) { return; }
      const size_t count = gptr() - mark;
      if (count > max_frame - consumed.size())
      { throw std::length_error("GLVis frame exceeds 64 MiB"); }
      consumed.append(mark, count);
      mark = gptr();
   }
protected:
   int_type underflow() override
   {
      if (gptr() && gptr() != egptr()) { return traits_type::to_int_type(*gptr()); }
      collect();
      ssize_t size;
      do { size = ::read(STDIN_FILENO, buffer, sizeof(buffer)); }
      while (size < 0 && errno == EINTR);
      if (size < 0) { throw std::runtime_error(std::strerror(errno)); }
      if (!size) { return traits_type::eof(); }
      setg(buffer, buffer, buffer + size);
      mark = buffer;
      return traits_type::to_int_type(*gptr());
   }
public:
   std::string finish()
   {
      collect();
      std::string result;
      result.swap(consumed);
      return result;
   }
};

std::string quote(const std::string &value)
{
   std::string out = "\"";
   const char hex[] = "0123456789abcdef";
   for (unsigned char c : value)
   {
      if (c == '"' || c == '\\') { out += '\\'; out += c; }
      else if (c < 32) { out += "\\u00"; out += hex[c >> 4]; out += hex[c & 15]; }
      else { out += c; }
   }
   return out + '"';
}

void send(char kind, const std::string &payload)
{
   if (payload.size() > max_frame) { throw std::length_error("GLVis frame exceeds 64 MiB"); }
   std::cout << kind << ' ' << payload.size() << '\n';
   std::cout.write(payload.data(), payload.size());
   std::cout.flush();
   if (!std::cout) { throw std::runtime_error("Viewer disconnected"); }
}

std::string argument(std::istream &input, bool quoted)
{
   std::string result;
   input >> std::ws;
   const int first = input.peek();
   // MFEM examples also send quoted key sequences, e.g. keys 'Rjlm'.
   if (quoted || first == '\'' || first == '"')
   {
      char delimiter;
      input.get(delimiter);
      std::getline(input, result, delimiter);
   }
   else { input >> result; }
   if (!input) { throw std::runtime_error("Incomplete GLVis command argument"); }
   if (result.size() > 65536) { throw std::length_error("GLVis command is too long"); }
   return result;
}
}

int main()
{
   mfem::out.SetStream(std::cerr);
   RecordingBuffer buffer;
   std::istream input(&buffer);
   input.exceptions(std::ios::badbit);
   const std::map<std::string, int> arity = {
      {"keys",1}, {"pause",0}, {"autopause",1}, {"window_title",1},
      {"window_size",2}, {"window_geometry",4}, {"view",2}, {"viewcenter",2},
      {"zoom",1}, {"shading",1}, {"subdivisions",2}, {"valuerange",2},
      {"autoscale",1}, {"levellines",3}, {"palette",1}, {"palette_repeat",1},
      {"palette_file",1}, {"palette_name",1}, {"camera",9}, {"plot_caption",1},
      {"axis_labels",3}, {"axis_numberformat",1}, {"colorbar_numberformat",1},
      {"screenshot",1}, {"fix_orientations",1}, {"save_coloring",1}, {"keep_attributes",1}
   };
   std::map<std::string, std::string> settings;
   bool fix_orientation = true;
   try
   {
      while (input >> std::ws && input.peek() != EOF)
      {
         buffer.finish(); // discard inter-command whitespace
         std::string command;
         input >> command;
         if (!input) { throw std::runtime_error("Incomplete GLVis command"); }
         const bool legacy_gf = command.find("_gf_data") != std::string::npos;
         const bool legacy_vector = command == "vfem2d_data" || command == "vfem2d_data_keys" ||
                                    command == "vfem3d_data" || command == "vfem3d_data_keys";
         if (command == "solution" || command == "mesh" || command == "quadrature" ||
             legacy_gf || legacy_vector || command == "fem2d_data" || command == "fem3d_data")
         {
            mfem::Mesh mesh(input, 1, 0, fix_orientation);
            if (command == "solution" || legacy_gf)
            {
               input >> std::ws;
               if (input.peek() == 'C') { mfem::ComplexGridFunction field(&mesh, input); }
               else { mfem::GridFunction field(&mesh, input); }
            }
            else if (command == "quadrature") { mfem::QuadratureFunction field(&mesh, input); }
            else if (command != "mesh")
            {
               const int components = legacy_vector ? (command.find("3d") != std::string::npos ? 3 : 2) : 1;
               mfem::Vector values;
               for (int i = 0; i < components; ++i) { values.Load(input, mesh.GetNV()); }
            }
            if (command.size() > 5 && command.compare(command.size()-5, 5, "_keys") == 0)
            { argument(input, false); }
            if (!input) { throw std::runtime_error("Incomplete GLVis mesh or solution"); }
            std::string prefix;
            for (const auto &setting : settings)
            { prefix += setting.first + " " + setting.second + "\n"; }
            send('F', prefix + buffer.finish() + "\n");
            continue;
         }
         auto item = arity.find(command);
         if (item == arity.end())
         { throw std::runtime_error("Unsupported GLVis command: " + command); }
         const bool quoted = command == "window_title" || command == "plot_caption" ||
                             command == "axis_labels" || command == "axis_numberformat" ||
                             command == "colorbar_numberformat";
         std::vector<std::string> args;
         for (int i = 0; i < item->second; ++i) { args.push_back(argument(input, quoted)); }
         if (command == "fix_orientations" || command == "save_coloring" || command == "keep_attributes")
         {
            settings[command] = args[0];
            if (command == "fix_orientations") { fix_orientation = args[0] != "off" && args[0] != "0"; }
            continue;
         }
         std::string json = "{\"command\":" + quote(command) + ",\"args\":[";
         for (size_t i = 0; i < args.size(); ++i)
         { if (i) { json += ','; } json += quote(args[i]); }
         send('C', json + "]}");
      }
   }
   catch (const std::exception &error)
   {
      std::cerr << "GLVis stream: " << error.what() << '\n';
      return 1;
   }
   return 0;
}
