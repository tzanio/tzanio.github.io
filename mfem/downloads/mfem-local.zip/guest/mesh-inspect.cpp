// Inspect the exact GLVis snapshot with MFEM's own mesh and field readers.
// No interpolation of exported values or reconstruction of finite elements in JS.
#include "mfem.hpp"
#include <algorithm>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <memory>
#include <sstream>
#include <stdexcept>

using namespace mfem;
namespace
{
std::string quote(const std::string &text)
{
   std::ostringstream out; out << '"';
   for (unsigned char c : text)
   {
      if (c == '"' || c == '\\') { out << '\\' << c; }
      else if (c < 32) { out << "\\u" << std::hex << std::setw(4) << std::setfill('0') << int(c) << std::dec; }
      else { out << c; }
   }
   out << '"'; return out.str();
}
void number(real_t value)
{ if (std::isfinite(value)) { std::cout << value; } else { std::cout << "null"; } }
void vector(const Vector &value)
{
   std::cout << '[';
   for (int i=0; i<value.Size(); ++i) { if(i) { std::cout << ','; } number(value(i)); }
   std::cout << ']';
}
void counts(const std::map<int,int> &items)
{
   bool comma=false; std::cout << '[';
   for (auto item : items)
   {
      if (comma) { std::cout << ','; } comma=true;
      std::cout << '[' << item.first << ',' << item.second << ']';
   }
   std::cout << ']';
}
const int (*edges(Geometry::Type geom))[2]
{
   switch (geom)
   {
      case Geometry::SEGMENT: return Geometry::Constants<Geometry::SEGMENT>::Edges;
      case Geometry::TRIANGLE: return Geometry::Constants<Geometry::TRIANGLE>::Edges;
      case Geometry::SQUARE: return Geometry::Constants<Geometry::SQUARE>::Edges;
      case Geometry::TETRAHEDRON: return Geometry::Constants<Geometry::TETRAHEDRON>::Edges;
      case Geometry::CUBE: return Geometry::Constants<Geometry::CUBE>::Edges;
      case Geometry::PRISM: return Geometry::Constants<Geometry::PRISM>::Edges;
      case Geometry::PYRAMID: return Geometry::Constants<Geometry::PYRAMID>::Edges;
      default: return nullptr;
   }
}
// MFEM's perfect-element Jacobian removes the reference simplex's anisotropy.
// The smallest/largest singular-value ratio is 1 for an ideal element, 0 when
// degenerate. Sample at the center and quadrature points; not a positivity proof.
real_t quality(Mesh &mesh, int element, const IntegrationPoint &ip, bool &nonpositive)
{
   DenseMatrix jac(mesh.SpaceDimension(),mesh.Dimension()), gram;
   mesh.GetElementJacobian(element,jac,&ip);
   if (jac.Height()==jac.Width() && jac.Det()<=0) { nonpositive=true; return 0; }
   if (jac.Width()==1) { return jac.FNorm()>0 ? 1 : 0; }
   gram.SetSize(jac.Width()); MultAtB(jac,jac,gram);
   real_t eigenvalues[3], eigenvectors[9]; gram.CalcEigenvalues(eigenvalues,eigenvectors);
   const real_t hi=eigenvalues[jac.Width()-1],lo=eigenvalues[0];
   return hi>0 ? std::sqrt(std::max(real_t(0),lo)/hi) : 0;
}
void report(Mesh &mesh, GridFunction *field, const std::string &unsupported)
{
   const int dim=mesh.Dimension(), sdim=mesh.SpaceDimension();
   if (dim<1 || dim>3 || sdim<1 || sdim>3) { throw std::runtime_error("Inspection supports mesh dimensions 1–3."); }
   std::map<int,int> attributes,boundary;
   for (int i=0;i<mesh.GetNE();++i) { ++attributes[mesh.GetAttribute(i)]; }
   for (int i=0;i<mesh.GetNBE();++i) { ++boundary[mesh.GetBdrAttribute(i)]; }
   Vector low,high; mesh.GetBoundingBox(low,high,4);
   real_t qmin=1,qmax=0,sum=0; int nonpositive=0,worst=-1,samples=0;
   std::vector<real_t> qualities(mesh.GetNE());
   for (int i=0;i<mesh.GetNE();++i)
   {
      auto geom=mesh.GetElementBaseGeometry(i); bool invalid=false;
      real_t q=quality(mesh,i,Geometries.GetCenter(geom),invalid); ++samples;
      const auto &rule=IntRules.Get(geom,2);
      for(int j=0;j<rule.GetNPoints();++j) { q=std::min(q,quality(mesh,i,rule.IntPoint(j),invalid)); ++samples; }
      qualities[i]=q; if(invalid) { ++nonpositive; }
      if(worst<0 || q<qmin) { qmin=q;worst=i; } qmax=std::max(qmax,q);sum+=q;
   }
   std::cout << "{\"dimension\":" << dim << ",\"spaceDimension\":" << sdim
      << ",\"vertices\":" << mesh.GetNV() << ",\"elements\":" << mesh.GetNE()
      << ",\"boundaryElements\":" << mesh.GetNBE() << ",\"elementAttributes\":"; counts(attributes);
   std::cout << ",\"boundaryAttributes\":";counts(boundary);
   std::cout << ",\"bounds\":[";vector(low);std::cout << ',';vector(high);std::cout << ']';
   std::cout << ",\"quality\":{\"min\":";number(mesh.GetNE()?qmin:0);
   std::cout << ",\"max\":";number(qmax);std::cout << ",\"mean\":";number(mesh.GetNE()?sum/mesh.GetNE():0);
   std::cout << ",\"worstElement\":" << worst << ",\"nonpositive\":" << nonpositive << ",\"samples\":" << samples << '}';
   std::cout << ",\"field\":{\"collection\":" << quote(field ? field->FESpace()->FEColl()->Name() : "")
      << ",\"components\":" << (field ? field->VectorDim() : 0)
      << ",\"unsupported\":" << quote(unsupported) << "},\"preview\":[";
   // Bound the preview without dropping elements from the quality statistics.
   // Sample actual transformed edges, including curved high-order geometry.
   const int cap=2500, stride=std::max(1,(mesh.GetNE()+cap-1)/cap); bool comma=false;
   for(int i=0;i<mesh.GetNE();i+=stride)
   {
      auto geom=mesh.GetElementBaseGeometry(i);auto indices=edges(geom);
      if(!indices) { continue; }
      auto refs=Geometries.GetVertices(geom);auto trans=mesh.GetElementTransformation(i);
      for(int e=0;e<Geometry::NumEdges[geom];++e)
      {
         if(comma) {std::cout << ',';}comma=true;
         std::cout << '[' << i << ',' << mesh.GetAttribute(i) << ',';number(qualities[i]);std::cout << ",[";
         const auto &a=refs->IntPoint(indices[e][0]),&b=refs->IntPoint(indices[e][1]);
         for(int k=0;k<=4;++k)
         {
            const real_t t=k/real_t(4);IntegrationPoint ip;
            ip.Set3((1-t)*a.x+t*b.x,(1-t)*a.y+t*b.y,(1-t)*a.z+t*b.z);
            Vector point;trans->Transform(ip,point);if(k) {std::cout << ',';} vector(point);
         }
         std::cout << "]]";
      }
   }
   std::cout << "],\"previewStride\":" << stride << ",\"boundaryPreview\":[";
   const int boundary_stride=std::max(1,(mesh.GetNBE()+cap-1)/cap);comma=false;
   for(int i=0;i<mesh.GetNBE();i+=boundary_stride)
   {
      auto geom=mesh.GetBdrElementBaseGeometry(i);auto indices=edges(geom);
      if(!indices) { continue; }
      auto refs=Geometries.GetVertices(geom);auto trans=mesh.GetBdrElementTransformation(i);
      for(int e=0;e<Geometry::NumEdges[geom];++e)
      {
         if(comma) {std::cout << ',';}comma=true;
         std::cout << '[' << i << ',' << mesh.GetBdrAttribute(i) << ",[";
         const auto &a=refs->IntPoint(indices[e][0]),&b=refs->IntPoint(indices[e][1]);
         for(int k=0;k<=4;++k)
         {
            const real_t t=k/real_t(4);IntegrationPoint ip;
            ip.Set3((1-t)*a.x+t*b.x,(1-t)*a.y+t*b.y,(1-t)*a.z+t*b.z);
            Vector point;trans->Transform(ip,point);if(k) {std::cout << ',';} vector(point);
         }
         std::cout << "]]";
      }
   }
   std::cout << "],\"boundaryPreviewStride\":" << boundary_stride << '}';
}
void probe(Mesh &mesh,GridFunction *field,const std::string &unsupported,int argc,char **argv)
{
   const int sdim=mesh.SpaceDimension();
   if(argc!=4+sdim) { throw std::runtime_error("Provide one coordinate per spatial dimension."); }
   Vector point(sdim);
   for(int d=0;d<sdim;++d)
   {
      size_t end=0;point(d)=std::stod(argv[4+d],&end);
      if(end!=std::strlen(argv[4+d]) || !std::isfinite(point(d))) { throw std::runtime_error("Coordinates must be finite numbers."); }
   }
   std::cout << "{\"point\":";vector(point);
   for(int e=0;e<mesh.GetNE();++e)
   {
      auto trans=mesh.GetElementTransformation(e);InverseElementTransformation inverse(trans);
      inverse.SetInitialGuessType(InverseElementTransformation::ClosestPhysNode);
      IntegrationPoint ip;
      if(inverse.Transform(point,ip)!=InverseElementTransformation::Inside) { continue; }
      // Inverse maps of embedded surfaces can identify a reference point even
      // when the physical point is off the surface; check its physical residual.
      Vector actual;trans->Transform(ip,actual);actual-=point;
      if(actual.Norml2()>1e-8*std::max(real_t(1),point.Norml2())) { continue; }
      std::cout << ",\"found\":true,\"element\":" << e << ",\"attribute\":" << mesh.GetAttribute(e)
         << ",\"values\":";
      if(field) { Vector value;field->GetVectorValue(e,ip,value);vector(value); }
      else { std::cout << "null"; }
      std::cout << ",\"unsupported\":" << quote(unsupported) << '}';return;
   }
   std::cout << ",\"found\":false}";
}
}
int main(int argc,char **argv)
{
   mfem::out.SetStream(std::cerr);std::cout << std::setprecision(15);
   try
   {
      if(argc<3) { throw std::runtime_error("Usage: studio-mesh-inspect stream report|probe [--point x y z]"); }
      std::ifstream input(argv[1]);std::string kind;bool fix=true;
      while(input>>kind)
      {
         if(kind=="fix_orientations" || kind=="save_coloring" || kind=="keep_attributes")
         { std::string value;input>>value;if(kind=="fix_orientations") { fix=value!="0" && value!="off"; } }
         else { break; }
      }
      if(kind!="mesh" && kind!="solution") { throw std::runtime_error("Inspection currently supports serial mesh and solution streams; this stream is "+kind+"."); }
      Mesh mesh(input,1,0,fix);std::unique_ptr<GridFunction> field;std::string unsupported;
      if(kind=="solution")
      {
         input>>std::ws;
         if(input.peek()=='C') { unsupported="Complex fields: mesh inspection is available; point values are not supported."; }
         else { field=std::make_unique<GridFunction>(&mesh,input); }
      }
      else { unsupported="Mesh-only stream: no solution values."; }
      if(std::string(argv[2])=="probe") { probe(mesh,field.get(),unsupported,argc,argv); }
      else if(std::string(argv[2])=="report") { report(mesh,field.get(),unsupported); }
      else { throw std::runtime_error("Unknown inspection operation."); }
      std::cout << '\n';return 0;
   }
   catch(const std::exception &error) { std::cerr << error.what() << '\n';return 1; }
}
