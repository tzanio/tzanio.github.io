#!/usr/bin/python3
"""Review and export MFEM working-tree changes without touching the user's index."""
import contextlib
import datetime
import io
import json
import os
from pathlib import Path
import stat
import subprocess
import tarfile
import tempfile

ROOT = Path('/root/mfem')
BASE = 'd964264cdb9a13e94a201b6c236c7721e0c8765f'
MAX_PREVIEW = 1024 * 1024


def git(root, *args, env=None):
    result = subprocess.run(['git', '-c', 'core.quotepath=false', '-C', str(root), *args],
                            env=env if env is not None else dict(os.environ, GIT_OPTIONAL_LOCKS='0'),
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode:
        raise ValueError(result.stderr.decode('utf-8', 'replace').strip() or 'Git failed')
    return result.stdout


def base_commit(root):
    # The shipped release, not HEAD: local commits must remain in the export.
    candidate = os.environ.get('MFEM_BASE_COMMIT', BASE)
    return git(root, 'rev-parse', '--verify', candidate + '^{commit}').decode().strip()


def relative_path(value):
    if not isinstance(value, str) or not value or '\x00' in value:
        raise ValueError('Choose a workspace file')
    path = Path(value)
    if path.is_absolute():
        try:
            path = path.relative_to(ROOT)
        except ValueError:
            raise ValueError('Files must be inside /root/mfem')
    if '..' in path.parts or not path.parts or path.parts[0] == '.git':
        raise ValueError('Files must be inside the MFEM working tree')
    return path.as_posix()


def status(root):
    fields = git(root, 'status', '--porcelain=v1', '-z', '--untracked-files=all').split(b'\x00')
    entries = []
    index = 0
    while index < len(fields) and fields[index]:
        field = fields[index]
        index += 1
        code, name = field[:2].decode('ascii'), os.fsdecode(field[3:])
        item = {'status': code, 'path': name}
        if 'R' in code or 'C' in code:
            item['from'] = os.fsdecode(fields[index])
            index += 1
        entries.append(item)
    base = base_commit(root)
    return {'base_commit': base, 'head': git(root, 'rev-parse', 'HEAD').decode().strip(),
            'branch': git(root, 'rev-parse', '--abbrev-ref', 'HEAD').decode().strip(),
            'entries': entries}


@contextlib.contextmanager
def private_index(root, base):
    with tempfile.TemporaryDirectory(prefix='mfem-changes-') as temporary:
        env = dict(os.environ, GIT_INDEX_FILE=str(Path(temporary) / 'index'), GIT_OPTIONAL_LOCKS='0')
        git(root, 'read-tree', base, env=env)
        # Include untracked non-ignored files, deletions, modes, symlinks and binary
        # changes. The actual staging index and the work tree are never written.
        git(root, 'add', '--all', '--', '.', env=env)
        yield env


def patch(root, selected=None):
    base = base_commit(root)
    with private_index(root, base) as env:
        args = ['diff', '--cached', '--binary', '--full-index', '--no-ext-diff', '--no-textconv', base, '--']
        if selected:
            args.extend(relative_path(item) for item in selected)
        return base, git(root, *args, env=env)


def add_bytes(archive, name, content):
    info = tarfile.TarInfo(name)
    info.size, info.mode = len(content), 0o644
    archive.addfile(info, io.BytesIO(content))


def export(request, root, progress):
    progress('changes', unit='files', detail='Comparing with the shipped MFEM commit')
    base, content = patch(root, request.get('paths'))
    descriptor, filename = tempfile.mkstemp(prefix='mfem-reproduction-' if request['op'] == 'reproduction-export' else 'mfem-changes-', suffix='.tar.gz')
    os.close(descriptor)
    try:
        with tarfile.open(filename, 'w:gz', compresslevel=1) as archive:
            add_bytes(archive, 'changes.patch', content)
            metadata = status(root)
            metadata.update({'format': 1, 'mfem': '4.10', 'base_commit': base,
                             'created': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                             'scope': request.get('paths') or 'all non-ignored working-tree changes'})
            if request['op'] == 'reproduction-export':
                metadata['command'] = str(request.get('command', ''))[:16384]
                metadata['cwd'] = str(request.get('cwd', '/root/mfem/examples'))[:4096]
                metadata['tests'] = str(request.get('tests', ''))[:16384]
                metadata['runtime'] = request.get('runtime', {})
                log = str(request.get('log', '')).encode('utf-8')[-1024 * 1024:]
                add_bytes(archive, 'terminal.log', log)
                metadata['meshes'] = []
                for value in request.get('meshes', []):
                    relative = relative_path(value)
                    target = root / relative
                    if not target.resolve().is_relative_to(root.resolve()):
                        raise ValueError('Mesh link leaves the workspace: ' + relative)
                    info = target.stat()
                    if not stat.S_ISREG(info.st_mode) or info.st_size > 128 * 1024 * 1024:
                        raise ValueError('Choose a regular mesh file smaller than 128 MiB')
                    progress('packing', unit='files', detail=relative)
                    archive.add(target.resolve(), arcname='inputs/' + relative, recursive=False)
                    metadata['meshes'].append({'path': relative, 'bundle_path': 'inputs/' + relative})
            add_bytes(archive, 'reproduction.json', json.dumps(metadata, indent=2, ensure_ascii=True).encode() + b'\n')
            add_bytes(archive, 'README.txt', (
                'MFEM browser working-tree changes\n\n'
                'Base commit: ' + base + '\n'
                'On a clean checkout of this base, review and apply:\n'
                '  git apply --check /path/to/changes.patch\n'
                '  git apply --binary /path/to/changes.patch\n\n'
                'The patch includes committed, staged, unstaged and untracked non-ignored\n'
                'working-tree content relative to the shipped base. Git history/staging,\n'
                'ignored outputs and browser editor drafts are not in the patch.\n'
                'Use Export workspace for a full portable workspace archive.\n'
                'Reproduction bundles also include the entered command, terminal log,\n'
                'runtime/test metadata and any explicitly selected mesh files.\n'
            ).encode())
        progress('packing', 1, 1, unit='archives', final=True)
        return {'path': filename, 'size': os.path.getsize(filename), 'base_commit': base}
    except Exception:
        os.unlink(filename)
        raise


def dispatch(request, progress=lambda *a, **k: None, root=None):
    root = Path(root or ROOT)
    op = request['op']
    if op == 'changes-status':
        return status(root)
    if op == 'changes-diff':
        base, content = patch(root, request.get('paths'))
        return {'base_commit': base, 'text': content[:MAX_PREVIEW].decode('utf-8', 'replace'),
                'bytes': len(content), 'truncated': len(content) > MAX_PREVIEW}
    if op in ('changes-export', 'reproduction-export'):
        return export(request, root, progress)
    raise ValueError('Unknown changes operation: ' + op)
